<? php
?>
<html>
<head>
<title> IBMPage</title>
</head>
<body bgcolor = "lightyellow">
<font face="verdana" size="4">
<p align="center">IBM produces and sells computer hardware, middlewear and software .</p><br>
<table border="0" align="center" cellpadding="5" cellspacing="5">
<tr>
	<td><a href = "ibm_written.php">Written Test</a>
</tr>
<tr>
	<td><a href = "ibm_technical.php">Technical Interview</a>
</tr>
<tr>
	<td><a href="ibm_hr.php">HR Interview </a>
</tr>
</table>
</font>
</body>
</html>