<?php
?>
<html>
<head><title>DBMS</title></head>
<body>
<h1>DBMS</h1>
<font size="3" face="verdana">
<hr width="50%" align="left">
<font color="red"><b>Q1. What is the use of DBMS?</b></font><br>
<b>Answer:</b>DBMS is also known as Database Management System. <br>
It is an application system wherein its main purpose is to revolve around data. 
This allows its user to store the data, define it, retrieve it and update the information about the data inside the database.
<hr width="50%" align="left">
<font color="red"><b>Q2. What do you mean by Database?</b></font><br>
<b>Answer:</b> Simply put, Database refers collection of data in some organized way to facilitate its user's to easily access, manage and upload the data.
<hr width="50%" align="left">
<font color="red"><b>Q3. Why is the use of DBMS recommended? Explain by listing any 4 of its major advantages.</b></font><br>
<b>Answer:</b> Reducing Data Redundancy: DBMS supports a mechanism to reduce the data redundancy inside the database by integrating all the data into a single database and as data is stored at only one place, the duplicity of data does not happen.<br>
<b>Sharing Data:</b> Sharing data among multiple users can be done simultaneously in DBMS as the same database will also be shared among all the users and by different application programs. <br>
<br>
<b>Data Integrity:</b> This means that the data is always accurate and consistent in the database. It is very important as there are multiple databases in a DBMS and all of these databases contain data that happens to be visible to multiple users. So it is vital to ensure that the data is correct and consistent in all the databases and for all the users. <br>
<br>
<b>Data Security:</b> In data security, only authorised users are allowed to access the database and their identity should be authenticated using a valid username and password. Unauthorised users are not be allowed to access the database under any circumstances as doing so violates the integrity constraints.
<hr width="50%" align="left">
<font color="red"><b>Q4. What is normalization needed in DBMS?</b></font><br>
<b>Answer:</b> Normalization is the process of analyzing relational schemas which are based on their respective functional dependencies and the primary keys so that they fulfill certain properties.<br>
Properties:
<ul>
	<li>To minimize data redundancy.
	<li>To minimize the anomalies of Insert, Delete and Update.
</ul>
<hr width="50%" align="left">
<font color="red"><b>Q5. Explain the concepts of a Primary key and Foreign Key.</b></font><br>
<b>Answer:</b> Primary Key uniquely identifies the records in a database table while Foreign Key, on the other hand, is used to link two or more tables together.<br>
Example: Consider 2 tables - Employee and Department. Both have one common field/column as 'ID' where ID is the primary key of the Employee table while this happens to be the foreign key for the Department table.
<hr width="50%" align="left">
<font color="red"><b>Q6. What is the biggest difference between UNION and UNION ALL?</b></font><br>
<br>
<b>Answer:</b>They are both used to join the data from 2 or more tables but UNION removes duplicate rows and picks the rows which are distinct after combining the data from the tables whereas UNION ALL, unlike UNION, does not remove the duplicate rows, it just picks all the data from the tables.
<hr width="50%" align="left">
<font color="red"><b>Q7. Explain the concept of ACID properties in DBMS?</b></font><br>
<b>Answer:</b> ACID properties are a combination of Atomicity, Consistency, Isolation, and Durability properties. These properties prove to be very helpful in allowing a safe and secure way of sharing the data amongst multiple users. <br>
<b>Atomicity:</b> When changes are being done to the data it feels as though a single operation is performed. In other words, either all the changes are performed, or none of them is performed.<br>
<b>Consistency:</b> Data must be in a consistent state at the beginning of the transaction as well as the end of the transaction.<br>
<b>Isolation:</b> As the name itself suggests, this ensures that each transaction that occurs is in isolation with others. Simply put a transaction which has started but not yet completed should be in isolation with others, this is done so that the other transaction does not get impacted with this transaction.<br>
<b>Durability:</b> In the event of system failure, after the transaction is completed, changes to the data persist and are not undone. Hence, due to this property data is always in a durable state.<br>
</font>
</body>
</html>