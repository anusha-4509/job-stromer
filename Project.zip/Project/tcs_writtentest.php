<?php
?>
<html>
<head>
<title>Written Test</title>
<body bgcolor = "lightyellow">
<font face="corbel" size="4">
<p align="center">The recruitment drive starts with a written test followed by a one on one interview. They may also conduct a group discussion for some students. Sometimes they waive the written test for students above aggregate of 75, and they were allowed to appear directly for the interview without a written test.The written test consists of 4 sections 
 </p><br>
<table border="0" align="center" cellpadding="5" cellspacing="5">
<tr>
	<td><a href = "tcs_reasoning.php">Reasoning</a>
</tr>
<tr>
	<td><a href = "tcs_verbal.php">Verbal Ability</a>
</tr>
<tr>
	<td><a href="tcs_coding.php">Coding Round</a>
</tr>
</table>
</font>
</body>
</head>
</html>