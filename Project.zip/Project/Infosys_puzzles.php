<?php
session_start();
require('connection.php');?>
<html>
<head><title>Puzzles</title></head>
<body>
<h1>Puzzles</h1>
<hr width="50%" align="left">
<font face="verdana" size="3">
I HAVE COLLECTED THESE QUESTIONS AND ANSWERS FROM THE MAILS IN THE GROUP ONLY. FOR 3-4 QUESTIONS ONLY I HAVE FOUND THE ANSWER WITH THE HELP OF MY TEACHERS. SO KEEP IN MIND THAT THESE ANSWERS MAY NOT BE 100% CORRECT. TRY TO SOLVE IT YOURSELF. <br><br>
1. You are given two candles of equal size, which can burn 1 hour each. You have to measure 90 minutes with these candles. (There is no scale or clock). Also u r given a lighter. <br>
<b>Answer:</b>First light up the two ends of the 1st candle. When it will burn out light up one end of the second candle. (30+60=90) 
<hr width="50%" align="left">
2. Try the similar problem to measure 45 minutes. <br>
<b>Answer:</b>First light-up the two ends of the 1st candle and one end of the 2nd candle. When the 1st candle will burn out ,then light up the both ends of the 2nd candle (15+30=45)
<hr width="50%" align="left">
3. You r given a thermometer. What can u do by this without measuring the temperature?<br> 
<b>Answer:</b> if u put thermometer into a tree it won't grow anymore, will just die off 
<hr width="50%" align="left">
4. How it is possible to place four points that are equidistance from each other? <br>
OR <br>
U r a landscape designer and your boss asked u to design a landscape such that you should place 4 trees equidistance from each other. 
(Distance from each tree to the other must be same) <br>
<b>Answer:</b> Only 3 points can be equidistant from each other. But if u place points in the shape of a pyramid then its possible 
<hr width="50%" align="left">
5. You are given a cake; one of its corner is broken. How will u cut the rest into Two equal parts? <br>
<b>Answer:</b> Slice the cake 
<hr width="50%" align="left">
6. How will you recognize the magnet & magnetic material & non-magnetic material? <br>
<b>Answer:</b> Drag one piece of material over another. There is no attractive force in the middle portion of the magnet. OR 
Get a piece of thread and tie up with the one bar and check for poles. If it iron bar then it moves freely and if it is magnetic bar then it fix in one direction according to poles. 
<hr width="50%" align="left">
7. If one tyre of a car suddenly gets stolen.... and after sometime u find the tyre without the screws how will u make ur journey complete? <br>
<b>Answer:</b> Open 3 screws, 1 from each tyre and fix the tyre. 
<hr width="50%" align="left">
8. How can u measure a room height using a thermometer? <br>
<b>Answer:</b> temp varies with height. but its dependent on various other factors like humidity, wind etc. 
<hr width="50%" align="left">
9. What is the height of room if after entering the room with a watch ur head strikes a hanging bulb?<br>
<b>Answer:</b> Oscillate the hanging bulb. Calculate the time period for one complete oscillation by Simple Harmonic Motion (SHM) of the handing bulb. Put it in the formula T=2 * 3.14 * (L/G)^1/2<br> 
L will be the length of the hanging thread. <br>
Add the L with ur height to get the height of the room. <br>
OR <br>
<b>Answer:</b> Drop it from the room and find the time at which it strikes the floor. Using physics formula s = (at^2)/2 (IM NOT SURE ABOUT THIS ONE) 
<hr width="50%" align="left">
10. Color of bear.... if it falls from 1m height in 1s. <br>
<b>Answer:</b> We get 'g' perfect 10 which is only in poles...hence polar bear...color White
</font>
</body>
</html>