<?php
?>
<html>
<head>
<title>
Technical Interview
</title>
</head>
<body bgcolor = "lightyellow">
<font face="times" size="4">
<p align="center">You'll be expected to have a strong knowledge of C, C++, Java, Python. Basic technical questions from these languages will be asked. </p><br>
<table border="0" align="center" cellpadding="5" cellspacing="5">
<tr>
	<td><a href="cap_clang.php">C Language</a>
</tr>
<tr>
	<td><a href="cap_cpp.php">C++</a>
</tr>
<tr>
	<td><a href="cap_java.php">Java</a>
</tr>
<tr>
	<td><a href="cap_python.php">Python</a>
</tr>
<tr>
	<td><a href="cap_dbms.php">DBMS</a>
</tr>
</table>
</font>
</body>
</html>
