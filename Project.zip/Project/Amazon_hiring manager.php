<?php
?>
<html>
<head><title>Hiring Manager</title></head>
<body>
<h1>Hiring Manager</h1>
<font face="verdana" size="3">
<hr width="50%" align="left">
<font color="black"><b>Q1.Do you know our CEO? How do you pronounce his name?</b></font><br>


<hr width="50%" align="left">
<font color="black"><b>Q2.How would you solve problems if you were from Mars?  </b></font><br>

<hr width="50%" align="left">
<font color="black"><b>Q3. Tell the story of the last time you had to apologize to someone?</b></font><br>

<hr width="50%" align="left">
<font color="black"><b>Q4. What is the most difficult situation you have ever faced in your life? How did you handle it? </b></font><br>

<hr width="50%" align="left">
<font color="black"><b>Q5.Walk me through how Amazon Kindle books would be priced. </b></font><br>

<hr width="50%" align="left">
<font color="black"><b>Q6.Who was your most difficult customer? </b></font><br>

<hr width="50%" align="left">
<font color="black"><b>Q7. What would you do if you found out that your closest friend at work was stealing? </b></font><br>

<hr width="50%" align="left">
<font color="black"><b>Q8. If your direct manager was instructing you to do something you disagreed with, how would you handle it? </b></font><br>

<hr width="50%" align="left">
<font color="black"><b>Q9.What would you do if you saw someone being unsafe at work?</b></font><br>

<hr width="50%" align="left">
<font color="black"><b>Q10.Do you think you'll reach a point where you storm off the floor and never return? </b></font><br>


</font>
</body>
</html>