<?php
?>
<html>
<head>
<title>Written Test</title>
<body bgcolor = "lightyellow">
<font face="corbel" size="4">
<p align="center">Written test consists of three sections : </p><br>
<table border="0" align="center" cellpadding="5" cellspacing="5">
<tr>
	<td><a href = "cap_aptitude.php">Aptitude</a>
</tr>
<tr>
	<td><a href="cap_pseudo.php">Pseudo code</a>
</tr>
<tr>
	<td><a href="cap_verbal.php">Verbal</a>
</tr>
</table>
</font>
</body>
</head>
</html>