<?php
session_start();
require('connection.php');?>
<html>
<head><title>Verbal</title></head>
<body>
<h1>Verbal Questions</h1>
<hr width="50%" align="left">
<font face="verdana" size="3">
<b>Directions 1 - 10: Pick out the most effective word from the given words to fill in the blank to make the sentence meaningfully complete. </b><br><br>
1. These essays are intellectually ............. and represent various levels of complexity. 
<ol type="A">
	<li>Revealing 
	<li>Modern 
	<li>persistent 
	<li>demanding 
	<li>persistent 
</ol>
<b>Answer:</b>C 
<hr width="50%" align="left">
2. It was almost impossible for him to put out of his mind the ............. words which he heard from his clever father-in-law 
<ol type="A">
	<li>Inspiring 
	<li>witty 
	<li>sarcastic 
	<li>soothing 
	<li>exhortative 
</ol>
<b>Answer:</b> B 
<hr width="50%" align="left">
3. The integrity of character, honesty, dependability and discipline........... with a genuine interest in your work will go a long way in the achievement of success in your professional life. 
<ol type="A">
	<li>Coupled 
	<li>adjoined 
	<li>fixed 
	<li>attached 
	<li>joined 
</ol>
<b>Answer:</b> A 
<hr width="50%" align="left">
4. The soldiers were instructed to ............... restraint and handle the situation peacefully. 
<ol type="A">
	<li>exercise 
	<li>control 
	<li>prevent 
	<li>enforce 
	<li>remain 
</ol>
<b>Answer:</b> A 
<hr width="50%" align="left">
5. Ishwar Chandra Vidyasagar was one of the chief ............ of women's rights. 
<ol type="A">
	<li>Promoters 
	<li>facilitators 
	<li>instigators 
	<li>organizers 
	<li>protagonists 
</ol>
<b>Answer:</b> E 
<hr width="50%" align="left">
6. Her parents will never give their ......... to such an unsuitable match. 
<ol type="A">
	<li>willingness 
	<li>agreement 
	<li>consent 
	<li>acquiescence 
</ol>
<b>Answer:</b> C 
<hr width="50%" align="left">
7. He is  ............ dancer 
<ol type="A">
	<li>a skilled 
	<li>an adept 
	<li>an adapt 
	<li>an adopt 
</ol>
<b>Answer:</b> A 
<hr width="50%" align="left">
8. The degrees were awarded in the annual .......... 
<ol type="A">
	<li>conference 
	<li>convention 
	<li>Convolution 
	<li>convocation 
</ol>
<b>Answer:</b> D 
<hr width="50%" align="left">
9. They ............ TV ever since they came home. 
<ol type="A">
	<li>watched 
	<li>have watched 
	<li>have been watching 
	<li>should watch 
</ol>
<b>Answer:</b> C 
<hr width="50%" align="left">
10. That is a moving story ............... 
<ol type="A">
	<li>that had survived the centuries. 
	<li>that has survived the centuries. 
	<li>which is survived by the centuries. 
	<li>that is a survival in the centuries. 
</ol>
<b>Answer:</b> B
</font>
</body>
</html>