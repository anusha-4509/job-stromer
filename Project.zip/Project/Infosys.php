<?php
session_start();
?>
<html>
<head>
<title> Infosys Page</title>
</head>
<body bgcolor="lightyellow">
<font face="verdana" size="4">
<p align="center">Infosys is one of the India's leading technology company. Infosys Ltd head quarters are in Bangalore, Karnataka. Company trade name as "Infosys Technologies Limited." The business provides consulting, information technology and outsourcing services. There are 3 rounds are conducted during company recruitment.</p><br>
<table border="0" align="center" cellpadding="5" cellspacing="5">
<tr>
	<td><a href = "infowrittentest.php">Written Test</a>
</tr>
<tr>
	<td><a href = "infosys_technical.php">Technical Interview</a>
</tr>
<tr>
	<td><a href="infosys_hr.php">HR Interview </a>
</tr>
</table>
</font>
</body>
</html>