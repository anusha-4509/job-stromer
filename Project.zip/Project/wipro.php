<?php
?>
<html>
<head>
<title> Infosys Page</title>
</head>
<body bgcolor = "lightyellow">
<font face="verdana" size="4">
<p align="center">Wipro is a company that is recognized globally for its comprehensive portforio of serrvices, strong commitment to sustainability and good corporate citizenship.
 </p><br>
<table border="0" align="center" cellpadding="5" cellspacing="5">
<tr>
	<td><a href = "writtentest.php">Written Test</a>
</tr>
<tr>
	<td><a href = "technical.php">Technical Interview</a>
</tr>
<tr>
	<td><a href="wipro_hr.php">HR Interview </a>
</tr>
</table>
</font>
</body>
</html>