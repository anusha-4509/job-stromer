<?php
?>
<html>
<head><title>Aptitude Test</title></head>
<body>
<h1>Aptitude Test</h1>
<font size="3" face="verdana">
<hr width="50%" align="left">
 1) A person gains 10% while buying and 10% while selling by using false weights, then what is his total profit percentage?
<ol type="a">
	<li>15%
	<li>25%
	<li>20%
	<li>21%
</ol>
<b>Answer:</b>21%<br>
<b>Explanation:</b> Here the 10% is successively increased, so (a+b+ab/100) can be used to find the overall percentage gain. %Profit = (10 + 10 + (10*10)/100) = 21
<hr width="50%" align="left">
2) Seema is 5 years older than her brother Mac. The product of their ages is 204 years. What is the age of Mac?
<ol type="a">
	<li>12 years
	<li>8 years
	<li>6 years
	<li>10 years
</ol>
<b>Answer:</b> 12 years<br>
<b>Explanation:</b>Let the age of Mac will be x yrs. Then Seema age =x+5 According to question: (x+5)x = 204, by solving this we get x= 12 years.
<hr width="50%" align="left">
 3) Lalit marks up his goods by 40% and gives a discount of 10%. Apart from this, he uses a faulty balance also, which reads 1000 gm for 800 gm. What is his net profit percentage?
<ol type="a">
	<li>57.5%
	<li>57%
	<li>61%
	<li>62.5%
</ol>
<b>Answer:</b>57.5%<br>
<b>Explanation:</b> Let us assume his CP/1000 gm = Rs 100 The SP/kg (800 gm) = Rs 126 So, his CP/800 gm = Rs 80 So, profit = Rs 46 So, profit percentage = 46/80 x 100 = 57.5%
<hr width="50%" align="left">
4) In a bag, there are a certain number of toy blocks with alphabets A, B, C, and D written on them. The ratio of blocks A:B: C:D is in the ratio 4:7:3:1. If the number of A blocks is 50 more than the number of C blocks, what is the number of B blocks?
<ol type="a">
	<li>120
	<li>350
	<li>240
	<li>210
</ol>
<b>Answer:</b> 350 <br>
<b>Explanation:</b> Let the number of the blocks A,B,C,D be 4x, 7x, 3x and 1x respectively 4x = 3x + 50 ? x = 50. So the number of B blocks is 7*50 = 350.
<hr width="50%" align="left">
5) If 60 ml of water contains 12% of chlorine, how much water must be added to create an 8% chlorine solution?
<ol type="a">
	<li>10ml
	<li>35ml
	<li>20ml              
	<li>30ml
</ol>
<b>Answer:</b> 30ml <br>
<b>Explanation:</b> Let x ml of chlorine be present in water. Then, 12/100 = x/60 ? x = 7.2 ml Therefore, 7.2 ml is present in 60 ml of water. For this 7.2 ml to constitute 8% of the solution, we need to add extra water. Let this be y ml, then 8/100 of y = 7.2ml? y = 90 ml. So to get an 8% chlorine solution, we need to add 90-60 = 30 ml of water
<hr width="50%" align="left">
6) If a : b = 7 : 5 and c : d = 2a : 3b, then ac : bd is :
<ol type="a">
	<li>14:15
	<li>50:147
	<li>98:75
	<li>15:14
</ol>
<b>Answer:</b> 98:75<br>
<b> Explanation:</b> Since a and b are in the ratio 7:5. Then, let a = 7x and b = 5x. c = 2a = 2 * 7x = 14x and d = 3b = 3 * 5x = 15x. c : d = 14 : 15 ac : bd = 14 * 7 : 15 * 5 = 98 : 75 
<hr width="50%" align="left">
7) The average score of a cricketer for ten matches is 38.9 runs. If the average for the first six matches is 42, then find the average for the last four matches.
<ol type="a">
	<li>33.25 
	<li>33.5
	<li>34.25
	<li>35 
</ol>
<b>Answer:</b> 34.25<br>
<b>Explanation:</b> Total sum of last 4 matches = (1038.9)(642) =389252=137 Average = 137/4 = 34.25
<hr width="50%" align="left">
 8) A grocer has a sale of Rs. 6435, Rs. 6927, Rs. 6855, Rs. 7230 and Rs. 6562 for 5 consecutive months. How much sale must he have in the sixth month so that he gets an average sale of Rs.6500?
<ol type="a">
	<li>Rs. 4991
	<li>Rs. 5467
	<li>Rs. 5987
	<li>Rs. 6453
</ol>
<b>Answer:</b> Rs. 4991<br>
<b>Explanation:</b> Total sale for 5 months = Rs. (6435 + 6927 + 6855 + 7230 + 6562) = Rs. 34009. Required sale = Rs.[(6500 x 6) - 34009] = Rs. (39000 - 34009) = Rs. 4991.
<hr width="50%" align="left">
9) The average of five consecutive odd numbers is 61. What is the difference between the highest and lowest numbers :
<ol type="a">
	<li>4
	<li>8
	<li>12
	<li>16
</ol>
<b>Answer:</b> 8 <br>
<b>Explanation:</b> Let the numbers be x, x + 2, x + 4, x + 6 and x + 8. Then [x + (x + 2) + (x + 4) + (x + 6) + (x + 8)] / 5 = 61. Or 5x + 20 = 305 or x = 57. So, required difference = (57 + 8) - 57 = 8
<hr width="50%" align="left">
10) A car travels at a speed of 60 km/h and returns with a speed of 40 km/h, calculate the average speed for the whole journey.
<ol type="a">
	<li>48 kmph
	<li>38 kmph
	<li>32 kmph
	<li>16 kmph
</ol>
<b>Answer:</b> 48 kmph <br>
<b>Explanation:</b> Since equal distances are covered at 60 kmph and 40 kmph, we can apply the formula 2xy/(x+y). Average speed = (24060) / (40 + 60) = 48 kmph
</font>
</body>
</html>