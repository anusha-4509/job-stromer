<?php
?>
<html>
<head>
</head>
<frameset rows="15%,85%">
	<frame src = "index.php" name="top">
	<frameset cols="20%,80%">
		<frame src="company.php" name="left">
		<frame src="empty.php" name="right">
	</frameset>
</frameset>
</html>