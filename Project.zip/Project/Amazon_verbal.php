<?php
?>
<html>
<head>
<title>verbal reasoning</title>
</head>
<body>
<h1>Amazon Verbal Reasoning Interview Questions</h1>
<hr width="50%" align="left">
<font face="verdana" size="3">
 1) The easiest way for prevent stress caused by work or home pressures is to indulge in high levels of physical activity 
<ol type="a">
	<li>easily way to 
	<li>easier ways for 
	<li>easiest way to 
	<li>easier way from 
                      <li>no correction required 
</ol>
<b>Answer:</b> c<br>
<br>

  <hr width="50%" align="left">
2)   For all sadness, poverty and diseases (1) / in this world (2) / everyone of us (3) / possesses unlimited ways of making a positive difference (4) / no errors (5) ? 
<ol type="a">
	<li>1
	<li>2
	<li>3
	<li>4
                      <li>5
</ol>
<b>Answer:</b> a<br><br>

<hr width="50%" align="left">
3)  Excess weight is the result of (1) / unhealthy eating habits (2) / which are inherent risk factors (3) / responsible for many diseases. (4) / no error (5) 
<ol type="a">
	<li>1
	<li>2
	<li>3
	<li>4
                      <li>5
</ol>
<b>Answer:</b> e <br><br>


<hr width="50%" align="left">
4)   The therapeutic benefits (1) / at helping others (2) / have long been (3) / recognised by people. (4) / no error (5) 
<ol type="a">
	<li>1
	<li>2
	<li>3
	<li>4
                      <li>5
</ol>
<b>Answer:</b> b<br><br>

<hr width="50%" align="left">
5)    Living with compassion and contributing to others lives would helping us add happiness to our lives. 
<ol type="a">
	<li>will helping us 
	<li>will help us 
	<li>would helped them 
	<li>will helped us 
                      <li>No correction required 
</ol>
<b>Answer:</b> b<br><br>

<hr width="50%" align="left">

</font>
</body>
</html>