<?php
$conn=mysqli_connect("localhost","root","","job_stromer1")or die(mysqli_error());
?>