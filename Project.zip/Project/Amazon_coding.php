<?php
?>
<html>
<head><title>Amazon Coding</title></head>
<body>
<h1>Amazon Coding</h1>
<font face="verdana" size="3">
<hr width="50%" align="left">
<font color="black"><b>Q1.K largest elements from an array ?  </b></font><br>

<hr width="50%" align="left">
<font color="black"><b>Q2. Convert a Binary tree to DLL ?  </b></font><br>

<hr width="50%" align="left">
<font color="black"><b>Q3.Given a binary tree T, find the maximum path sum. The path may start and end at any node in the tree? 
</b></font><br>

<hr width="50%" align="left">
<font color="black"><b>Q4.Rotate a matrix by 90 degrees ? </b></font><br>


<hr width="50%" align="left">
<font color="black"><b>Q5. Assembly line scheduling with dynamic programming ?</b></font><br>


<hr width="50%" align="left">
<font color="black"><b>Q6.Implement a stack with push(), min(), and pop() in O(1)O(1) time ? </b></font><br>


<hr width="50%" align="left">
<font color="black"><b>Q7. How do you rotate an array by K?</b></font><br>

<hr width="50%" align="left">
<font color="black"><b>Q8. Design Snake Game using Object Oriented analysis and design technique?</b></font><br>

<hr width="50%" align="left">
<font color="black"><b>Q9.Print all permutations of a given string using recursion ? </b></font><br>

<hr width="50%" align="left">
<font color="black"><b>Q10.Implement a queue using a linked list ?</b></font><br>

<hr width="50%" align="left">
<font color="black"><b>Q11.Find the longest increasing subsequence of an array ?
  </b></font><br>

<hr width="50%" align="left">
<font color="black"><b>Q12.Lowest common ancestor in a Binary Search Tree and Binary Tree ?   </b></font><br>

<hr width="50%" align="left">
<font color="black"><b>Q13.Rotate a given list to the right by k places, which is non-negative.? 
</b></font><br>

<hr width="50%" align="left">
<font color="black"><b>Q14.Write a function that counts the total of set bits in a 32-bit integer?  </b></font><br>


<hr width="50%" align="left">
<font color="black"><b>Q15.How do you detect a loop in a singly linked list? </b></font><br>


<hr width="50%" align="left">
<font color="black"><b>Q16.Reverse an array in groups ? </b></font><br>


<hr width="50%" align="left">
<font color="black"><b>Q17.Given a binary tree, check if it’s a mirror of itself ? </b></font><br>

<hr width="50%" align="left">
<font color="black"><b>Q18.Josephus problem for recursion? 
</b></font><br>

<hr width="50%" align="left">
<font color="black"><b>Q19.Zero Sum Subarrays ?  </b></font><br>

<hr width="50%" align="left">
<font color="black"><b>Q20.Huffman Decoding for greedy algorithms ? </b></font><br>
</font>
</body>
</html>