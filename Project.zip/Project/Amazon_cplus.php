<?php
?>
<html>
<head><title>C++</title></head>
<body>
<h1>C++</h1>
<font face="verdana" size="3">
<hr width="50%" align="left">
<font color="red"><b>Q1.What is the function of the keyword “Volatile”? </b></font><br>
<b>Answer:</b><br>
"Volatile" is a function that helps in declaring that the particular variable is volatile and thereby directs the compiler to change the variable externally- this way, the compiler optimization on the variable reference can be avoided.<br>
<br>
<hr width="50%" align="left">
<font color="red"><b>Q2. Define storage class in C++? Name some? </b></font><br>
<b>Answer:</b><br>
Storage class in C++ specifically resemble life or even the scope of symbols, including the variables, functions, etc. Some of the storage class names in C++ include mutable, auto, static, extern, register, etc.<br>
<br>
<hr width="50%" align="left">
<font color="red"><b>Q3. Can we have a recursive inline function in C++?</b></font><br>
<b>Answer:</b>
<br>Even though it is possible to call an inline function from within itself in C++, the compiler may not generate the inline code. This is so because the compiler won’t determine the depth of the recursion at the compile time.<br>
<br>
Nonetheless, a compiler with a good optimizer is able to inline recursive calls until some depth is fixed at compile-time and insert non-recursive calls at compile time for the cases when the actual depth exceeds run time.
<br>
<br>
<hr width="50%" align="left">
<font color="red"><b>Q4.Define an Inline Function in C++? Write its syntax. Is it possible for the C++ compiler to ignore inlining?</b></font><br>
<b>Answer:</b><br>
In order to reduce the function call overhead, C++ offers inline functions. As the name suggests, an inline function is expanded in line when it is called.<br>
<br>
As soon as the inline function is called, the whole code of the same gets either inserted or substituted at the particular point of the inline function call. The substitution is complete by the C++ compiler at compile time. Small inline functions might increase program efficiency.<br>
<br>
The syntax of a typical inline function is:<br>
<br>
Inline return-type function-name(parameters)<br>
<br>
{<br>
<br>
// Function code goes here<br>
<br>
}<br>
<br>
As the inlining is a request, not a command, the compiler can ignore it.
<br>
<br>
<hr width="50%" align="left">
<font color="red"><b>Q5. Explain ‘this’ pointer?</b></font><br>
<b>Answer</b><br>
The ‘this’ pointer is a constant pointer, and it holds the memory address of the current object. It passes as a hidden argument to all the nonstatic member function calls. Also, it is available as a local variable within the body of all the nonstatic functions.<br>
<br>
As static member functions can be called even without any object, i.e., with the class name, the ‘this’ pointer is not available for them.
<br>
 <br>
<hr width="50%" align="left">
<font color="red"><b>Q6.What are the most important differences between C and C++?</b></font><br>
<b>Answer:</b><br>
C++ supports references while C doesn’t<br>
<br>
Features like friend functions, function overloading, inheritance, templates, and virtual functions are inherent to C++. These are not available in the C programming language.<br>
<br>
In C, exception handling is taken care of in the traditional if-else style. On the other hand, C++ offers support for exception handling at the language level.<br>
<br>
Mainly used input and output in C are scanf() and printf(), respectively. In C++, cin is the standard input stream while cout serves as the standard output stream.<br>
<br>
While C is a procedural programming language, C++ provides support for both procedural and object-oriented programming approaches.<br>
<br>
<hr width="50%" align="left">
<font color="red"><b>Q7. Why do we need the Friend class and function?</b></font><br>
<b>Answer:</b><br>
Sometimes, there is a need for allowing a particular class to access private or protected members of a class. The solution is a friend class, which can access the protected and private members of the class in which it is declared as a friend.<br>
<br>
Similar to the friend class, a friend function is able to access private and protected class members. A friend function can either be a global function or a method of some class.<br>
<br>
Some important points about friend class and friend function:<br>
<br>
Friendship is not inherited.<br>
<br>
Friendship isn’t mutual, i.e., if some class called Friend is a friend of some other class called NotAFriend, then it doesn’t automatically become a friend of the Friend class.<br>
<br>
The total number of friend classes and friend functions should be limited in a program as the overabundance of the same might lead to a depreciation of the concept of encapsulation of separate classes, which is an inherent and desirable quality of object-oriented programming.<br>
<br>
<hr width="50%" align="left">
<font color="red"><b>Q8. Explain the significance of vTable and vptr in C++ and how the compiler deals with them</b></font><br>
<b>Answer:</b><br>
look for vptr using the base class pointer or reference. The vTable of a derived class can be accessed once the vptr is successfully fetched. Address of derived class function show() is accessed and called using the vTable.<br>
<br>
vTable is a table containing function pointers. Every class has a vTable. vptr is a pointer to vTable. Each object has a vptr. In order to maintain and use vptr and vTable, the C++ compiler adds additional code at two places:<br>
<br>
In every constructor – This code sets vptr:<br>
<br>
Of the object being created<br>
<br>
To point to vTable of the class<br>
<br>
Code with the polymorphic functional call – At every location where a polymorphic call is made, the compiler inserts code in order to first<br>
<br>
<hr width="50%" align="left">
<font color="red"><b>Q9.How is function overloading different from operator overloading?</b></font><br>
<b>Answer:</b><br>
Function overloading allows two or more functions with different type and number of parameters to have the same name. On the other hand, operator overloading allows for redefining the way an operator works for user-defined types.<br>
<br>
<hr width="50%" align="left">
<font color="red"><b>Q10.Is it possible for a C++ program to be compiled without the main() function?</b></font><br>
<b>Answer:</b><br>
Yes, it is possible. However, as the main() function is essential for the execution of the program, the program will stop after compiling and will not execute.<br>
<br>

</font>
</body>
</html>