<?php
session_start();
require('connection.php');?>
<html>
<head><title>Reasoning</title></head>
<body>
<h1>Reasoning</h1>
<hr width="50%" align="left">
<font face="verdana" size="3">

</font>
</body>
</html>