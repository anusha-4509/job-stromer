<?php
?>
<html>
<head><title>C Lang</title></head>
<body>
<h1>C Language</h1>
<hr width="50%" align="left">
<font face="verdana" size="3">
<font color="red"><b>Q1. What are the different storage class specifiers in C?</b></font><br>
<b>Answer:</b>
<ul>
	<li>auto
	<li>register
	<li>static
	<li>extern
</ul>
<hr width="50%" align="left">
<font color="red"><b>Q2. What is the scope of a variable?</b></font><br>
<b>Answer:</b><br>
Scope of a variable refers to the part of the program where the variable may directly be accessible. DO note that in C, all identifiers are lexically (or statically) scoped.
<hr width="50%" align="left">
<font color="red"><b>Q3. What is Dangling pointer?</b></font><br>
<b>Answer:</b>Dangling Pointer could be defined as a pointer that doesn’t point to a valid memory location. Dangling pointers are created when an object is deleted or deallocated, without modifying the value of the pointer, so that the pointer still points to the memory location of the deallocated memory.
<hr width="50%" align="left">
<font color="red"><b>Q4. What is a NULL pointer?</b></font><br>
<b>Answer:</b><br>
A NULL pointer is often used to indicate that the pointer doesn’t point to a valid location. In an ideal situation, we should initialize pointers as NULL if we are not aware of their value at the time of declaration. Also, a pointer must be made NULL when memory pointed by it is deallocated in the middle of a program.
<hr width="50%" align="left">
<font color="red"><b>Q5. What are the local static variables? What is their use?</b></font><br>
<b>Answer:</b><br>
 A local static variable could be defined as a variable whose life doesn’t end with a function call where it is declared. Local static variable extends for the lifetime of the complete program. All calls related to the function do share the same copy of local static variables. They can be used to count the number of times a function is called. DO note that initially, static variables get the default value is 0.
<hr width="50%" align="left">
<font color="red"><b>Q6. What are static functions? What is their use?</b></font><br>
<b>Answer:</b><br>
Functions happen to be global by default, in C. The static keyword before a function name makes the function static. Access to static functions is restricted to the file where they are declared as compared to the global functions. Therefore, to restrict access to functions, we make them static. By making functions static, they can reuse the same function name in other files.
</font>
</body>
</html>