<?php
session_start();
?>
<html>
<head>
<title>
Job Stromer
</title>
</head>
<body>
<h1  align="center" ><font face = "arial" color="black" ><u>Companies</u></font></h1>
<center>
<font face="times" size="6">
<table border="0" align="center">
<tr>
	<td><a href ="infosys.php" target="right"><img src="infosys.jpg" width="100" height="50"></img></a>
</tr>
<tr>
	<td><a href="tcs.php" target="right"><img src="tcs.jpg" width="100" height="50"></img></a>
</tr>
<tr>
	<td><a href="capgemini.php" target="right"><img src="capgemini.jpg" width="100" height="50"></img></a>
</tr>
<tr>
	<td><a href="wipro.php" target="right"><img src="wipro.jpg" width="100" height="50"></img></a>
</tr>
<tr>
	<td><a href ="amazon.php" target="right"><img src="amazon.jpg" width="100" height="50"></a>
</tr>
<tr>
	<td><a href = "ibm.php" target="right"><img src="ibm.jpg" width="100" height="50"></img></a>
</tr>
</table>
</font>
</center>
</body>
</html>
