<?php
?>
<html>
<head>
<title> Infosys Page</title>
</head>
<body bgcolor = "lightyellow">
<font face="verdana" size="4">
<p align="center">TCS (Tata Consultancy Service) Limited is an Indian multinational company which deals in consultancy service and Information technology. It is headquartered in Mumbai, India. It is a part of the Tata group and operates in 46 countries.
TCS is one of the largest Indian company by market capitalization and one of the most trusted Indian brands worldwide. It alone generates 70% of the dividends of its parent company Tata Sons.
Recently, Tata Sons decided to sell stocks of TCS worth $1.25 billion in a bulk deal. In 2015, TCS is ranked 64th overall in the Forbes World's Most Innovative Companies ranking, making it both the highest-ranked IT services company and the top Indian company.TCS conducts generally 3 rounds to select fresher as Software Developer in their organization
 </p><br>


<table border="0" align="center" cellpadding="5" cellspacing="5">
<tr>
	<td><a href = "tcs_writtentest.php">Written Test</a>
</tr>
<tr>
	<td><a href = "tcs_technical.php">Technical Interview</a>
</tr>
<tr>
	<td><a href="tcs_managerial.php">Managerial Interview</a>
</tr>
<tr>
	<td><a href="tcs_hr.php">HR Interview </a>
</tr>
</table>
</font>
</body>
</html>