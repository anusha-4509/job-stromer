<?php
?>
<html>
<head>
<title>HR</title>
</head>
<body>
<h1>HR Interview</h1>
<hr width="50%" align="left">
<font face="verdana" size="3">
<font color="red">Q1. Tell me about yourself.</font><br>
<b>Answer</b><br>
This question is asked to ease the candidate into the actual interview. <br>
Here are a few pointers that could help you while answering this.<br>
<ul>
	<li>Be succinct. Or in layman's terms don't waste your time regurgitating every single detail of your life.
	<li>Keep it professional but do inject some passion into your answer, this helps in engaging the interviewer and also sets you apart from the rest.
	<li>Try structuring your answer. You could first start with the present i.e your current achievements, then the past that could consist of previous experience relevant to the job. Finally, the future could include what you are looking for and why you are interested in the job.
	<li>Remember, your answer will help the interviewer find their next question.
</ul>
<hr width="50%" align="left">
<font color="red">Q2. What's your family background?</font><br>
<b>Answer</b>
<ul>
	<li>You must prepare for this question instead of fumbling.
	<li>Try to show good values that have been inculcated in you by your parents
	<li>You could even add a few things that have been taught to you by your family
</ul>
<hr width="50%" align="left">
<font color="red">Q3. Why choose Capgemini?</font><br>
<b>Answer:</b> 
<ul>
	<li>To answer this question you will have to do your research on the company.
	<li>This question gives the interviewer the perfect opportunity to find more about your career goals and how this job role will fit your plan.
	<li>You could highlight a few points on the company's general reputation, admiration for the products and services offered by the company, the company values and other initiatives taken by the company. 
</ul>
<hr width="50%" align="left">
<font color="red">Q4. Are you comfortable with reallocation?</font><br>
<b>Answer:</b>
<ul>
	<li>You could give a positive answer if you are willing to relocate anywhere they would like
	<li>This would show that you would do anything necessary to be a part of the company and the team.
	<li>Moving isn't exactly the best situation that you could be in, even though the job opportunity is exactly what you're looking for.
</ul>
Be confident while you are answering and if you do have queries about this, you could ask.
<hr width="50%" align="left">
<font color="red">Q5. What is the toughest decision that you have made in your life?</font><br>
<b>Answer:</b>
<ul>
	<li> The interviewer asks this question to see how well you can handle stressful situations.
	<li>This question could also be a good judge of your critical thinking skills.
	<li>Firstly, pick the right challenge.
	<li>Then discuss your options, how you weighed them and what made you choose one of them.
	<li> This should exhibit your ability to remain calm and solve problems in a difficult situation.
</ul>
<hr width="50%" align="left">
<font color="red">Q6. Have you had any gaps in your academic years?</font><br>
<b>Answer:</b>
<ul>
	<li>If you haven't had a gap during your academic years you could simply say no. But if you have had gaps in your academic years, here's how you could reply.
	<li>Give the interviewer a simple explanation of what you did during your gap year.
	<li>The reasoning behind your gap year proves to be compelling for an interview.
	<li> You could then further explain how your gap year helped you gain invaluable skills.
</ul>
<hr width="50%" align="left">
<font color="red">Q7. Did you work as a team leader?</font><br>
<b>Answer:</b>
<ul>
	<li> You could give an example that exhibits your decision and problem-solving skills
	<li>By working as a team leader, the interviewer now becomes aware that you are an excellent communicator and a good motivator.
</ul>
</font>
</body>
</html>