<?php
?>
<html>
<head><title>Python</title></head>
<body>
<h1>Python</h1>
<font face="verdana" size="3">
<hr width="50%" align="left">
<font color="red"><b>Q1.What are the built-in type does python provides?  </b></font><br>
<b>Answer:</b><br>
There are mutable and Immutable types of Pythons built in types Mutable built-in types • List • Sets • Dictionaries Immutable built-in types • Strings • Tuples • Numbers 
<br>
<br>
<hr width="50%" align="left">
<font color="red"><b>Q2.What is namespace in Python?  </b></font><br>
<b>Answer:</b><br>
In Python, every name introduced has a place where it lives and can be hooked for. This is known as namespace. It is like a box where a variable name is mapped to the object placed. Whenever the variable is searched out, this box will be searched, to get corresponding object. 
<br>
<br>
<hr width="50%" align="left">
<font color="red"><b>Q3.What is lambda in Python? </b></font><br>
<b>Answer:</b>
<br>It is a single expression anonymous function often used as inline function. 
<br>
<br>
<hr width="50%" align="left">
<font color="red"><b>Q4.Why lambda forms in python does not have statements? </b></font><br>
<b>Answer:</b><br>
A lambda form in python does not have statements as it is used to make new function object and then return them at runtime. <br>
<br>
<hr width="50%" align="left">
<font color="red"><b>Q5. What is pass in Python? </b></font><br>
<b>Answer</b><br>
Pass means, no-operation Python statement, or in other words it is a place holder in compound statement, where there should be a blank left and nothing has to be written there. 
<br>
 <br>
<hr width="50%" align="left">
<font color="red"><b>Q6.In Python what are iterators? </b></font><br>
<b>Answer:</b><br>
In Python, iterators are used to iterate a group of elements, containers like list. 
<br>
<br>
<hr width="50%" align="left">
<font color="red"><b>Q7. What is unittest in Python? </b></font><br>
<b>Answer:</b><br>
 A unit testing framework in Python is known as unittest. It supports sharing of setups, automation testing, shutdown code for tests, aggregation of tests into collections etc.<br>
<br>
<hr width="50%" align="left">
<font color="red"><b>Q8. In Python what is slicing? </b></font><br>
<b>Answer:</b><br>
A mechanism to select a range of items from sequence types like list, tuple, strings etc. is known as slicing. 
<br>
<br>
<hr width="50%" align="left">
<font color="red"><b>Q9.What are generators in Python? </b></font><br>
<b>Answer:</b><br>
The way of implementing iterators are known as generators. It is a normal function except that it yields expression in the function. 
<br>
<br>
<hr width="50%" align="left">
<font color="red"><b>Q10.What is docstring in Python? </b></font><br>
<b>Answer:</b><br>
A Python documentation string is known as docstring, it is a way of documenting Python functions, modules and classes.<br>
<br>

</font>
</body>
</html>