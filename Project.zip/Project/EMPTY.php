<?ph
?>
<html>
<head><title>Empty Page</title><head>
<body background="interview.jpg">
<font face="verdana" color="black" size="5">
<p align="center">This is a website where you will find all the common interview  questions asked by few reputated software  companies</p>
</font>
</body>
</html>