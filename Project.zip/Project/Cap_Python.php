<?php
?>
<html>
<head>
<title>
</title>
<body>
<h1>Python</h1>
<hr width="50%" align="left">
<font face="verdana" size="3">
<font color="red">Q1. Why is Python needed?</font><br>
<b>Answer:</b><br>
Python is a general-purpose and a high-level programming language and you could use Python for developing desktop GUI applications, websites and web applications. It lets you focus on the core functionality of the application by taking care of common programming tasks. The code in Python is easily readable and maintainable. It supports multiple programming paradigms It happens to be compatible with major platforms and systems Most importantly Python does have a very robust standard library
<hr width="50%" align="left">
<font color="red">Q2. Where is it used in real life?</font><br>
<b>Answer:</b><br>
Python could be used in: <br>
<ul>
	<li>Game development
	<li>Web development
	<li>Language development
	<li>Operating systems
	<li>Image processing
	<li>Graphic design applications
</ul>
<hr width="50%" align="left">
<font color="red">Q3. What are the key features of Python?</font><br>
<b>Answer:</b><br>
Python is an interpreted language. It is dynamically typed Python functions happen to be first-class objects, in other words, they can be assigned to variables, returned from other functions, and passed into functions. Writing the code in Python is quicker but running it is comparatively slower than in other languages It could be used in many spheres of life, such as game development, web applications, automation, and more. 
<hr width="50%" align="left">
<font color="red">Q4. How is memory managed in Python?</font><br>
<b>Answer:</b><br>
The memory is managed by Python private heap space. All Python objects and data structures are located in a private heap but the programmer does not have access to this private heap. Instead, this is taken care of by the Python interpreter.
<ul>
	<li>Python's memory manager is responsible for the allocation of heap space for Python objects. The core API then gives access to a few tools for the programmer to code. <br>
	<li>It also has an inbuilt garbage collector, as the name suggests this basically recycles all the unused memory and so that it can be made available to the heap space. 
</ul>
<hr width="50%" align="left">
<font color="red">Q5. What are modules in Python?</font><br>
<b>Answer:</b><br>
Python modules are could be referred to as files containing Python code and this code could either be function classes or variables. Simply put, a Python module is a .py file containing executable code. Given below are some of the commonly used built-in modules: 
<ul>
	<li>os 
	<li>sys
	<li>math 
	<li>random 
	<li>data time 
	<li>JSON 
</ul>
<hr width="50%" align="left">
<font color="red">Q6. Explain namespace in Python</font><br>
<b>Answer:</b><br>
Variables are the names or identifiers that map to objects. Whereas the namespace is a dictionary of variable names that could also be referred to as keys and their corresponding objects or values. A Python statement can access variables in a local as well as the global namespace. If a local and a global variable have the same name, then the local variable shadows the global variable.
<hr width="50%" align="left">
<font color="red">Q7. What is a dictionary in Python?</font><br>
<b>Answer:</b><br>
A dictionary in Python is the built-in data type. A dictionary in Python defines a one-to-one relationship between keys and values. They usually do contain a pair of keys and their corresponding values and are indexed by keys. 
</font>
</body>
</head>
</html>