<?ph
?>
<html>
<head>
<title>
</title>
</head>
<body bgcolor = "blue">
<table align="center" border="0" cellspacing="10" cellpadding="10">
<tr>
	<td><font face="Monotype Corsiva" color="white" size="7">Job Stromer</font>
	<td><img src="infosys.jpg" width="50" height="50"></img>
	<td><img src="tcs.jpg" width="50" height="50"></img>
	<td><img src="capgemini.jpg" width="50" height="50"></img>
	<td><img src="wipro.jpg" width="50" height="50"></img>
	<td><img src="amazon.jpg" width="50" height="50"></img>
	<td><img src="ibm.jpg" width="50" height="50"></img>
</tr>
</table>
</body>
</html>