<?php
session_start();
require('connection.php');?>
<html>
<head><title>Java</title></head>
<body>
<h1>Java</h1>
<hr width="50%" align="left">
<font face="verdana" size="3">
<font color="red">1. What is an Object in OOPs?</font><br>
Objects are runtime entities with some characteristics.<br>
Let us consider, a bouquet - Lillies, Roses, Tulips. Every flower has a few characteristics like different shapes, colors, odors. These are nothing but objects.
<hr width="50%" align="left">
<font color="red">2. What is a Class in OOPS?</font><br>
A class is an entity that determines how an object will behave and what the object will contain. In other words, it is a blueprint or a set of instructions to build a specific type of object.<br>
Let us consider the same example - a bouquet. Here, a bouquet is the class and the different types of flowers which comprise the bouquet are the objects. So we can say that objects are instances of a class.
<hr width="50%" align="left">
<font color="red">3. What are the basic OOPs principles?</font><br>
Object-oriented programming revolves around the concept of real-world entities as objects. It binds data and functions which operate on them so that no other part of the code can access the data except that function. Go over the basic constructs of OOPs - inheritance, polymorphism, encapsulation, and abstraction. Icing these concepts with real-world examples does real magic.<br>
Go can go over Inheritance in the following manner.<br>
Deriving the properties of the base class from the derived class is known as Inheritance. An example of a parent and the child is an interesting one. All the properties of the father are inherited by son/daughter because of the gene factor which is present.<br>
You can explain about Polymorphism like this.<br>
The process of representing one form in many other forms is called Polymorphism. For instance, you are a son/daughter at your house. At the same time, in a shopping mall you are a customer, In school, you are a student. So in this manner, an object takes different forms.<br>
Encapsulation can go like this.<br>
Encapsulation is the process of wrapping up of data and methods in a single unit.<br>
Last OOPs concept, Abstraction can be defined in the following manner.<br>
Abstraction is the process of hiding the internal details to protect from unauthorized access and only the external appearance is known. For instance, a cellphone. We only know how to operate a cellphone but do not know the internal workings of it.<br>
Explaining these above concepts with the help of a small code is the true essence of an Engineer.
<hr width="50%" align="left">
<font color="red">4.What is a constructor?</font><br>
A constructor is a special member function of a class, which is invoked automatically whenever an instance of the class is created. It has the same name as its class.<br>
Knowing this gives you bonus points. If a programmer does not create any constructor in the code explicitly, a default constructor is created by the compiler automatically. But if a programmer creates a constructor - parameterized or non-parameterized then the default constructor is not created by the compiler.
<hr width="50%" align="left">
<font color="red">5.What do you mean by access specifiers?</font><br>
Access specifiers are used to defining how the members (functions and variables) can be accessed outside the class. There are three access specifiers defined which are public, private, and protected
<ul>
	<li>private: Members declared as private are accessible only with in the same class and they cannot be accessed outside the class they are declared.
	<li>public: Members declared as public are accessible from anywhere.
	<li>protected: Members declared as protected can not be accessed from outside the class except a child class. This access specifier has significance in the context of inheritance
</ul>
<hr width="50%" align="left">
<font color="red">6.What is the difference between stack and heap memory?</font><br>
Answer:<br>
Heap - 
<ul>
	<li>JRE uses it to allocate memory for objects and JRE classes.
	<li>Garbage collection is done on heap memory
	<li>Objects created on heap are accessible globally.
</ul>
Stack - 
<ul>
	<li>Short term references like the current thread of execution
	<li>References to heap objects are stored in stack
	<li>When a method is called, a new memory block is created. Once the method gets executed, the block is used by the next program.
</ul>
Stack memory size is smaller compared to heap memory.
<hr width="50%" align="left">
<font color="red">7.How is exception handling done in C++ and Java?</font><br>
<b>Answer:</b> C++ and Java use the try/catch and throw keywords to handle exceptions. However,
<ul>
	<li>In Java only the instances of Throwable or subclasses of Throwable can be thrown as an exception. In C++, even primitive types and pointers are allowed to be thrown as an exception.
	<li>Java has finally block which is executed after try-catch block. This block is used to execute some code irrespective of what happens in the code (clean up, clearing variables etc...). there is no such provision in C++.
	<li>To list the set of exceptions a method can throw, Java uses the 'throws' keyword, whereas in C++, throw does the job.
	<li>All exceptions are unchecked in C++. Java can have checked and unchecked exceptions.
</ul>
<hr width="50%" align="left">
<font color="red">8.What is 'null' and how is memory allocation done for null objects?</font><br>
<b>Answer:</b> When a non-primitive variable doesn't point or refer to any object, it is called null.
<ul>
	<li>String str = null; //declaring null
	<li>if(str == null) //Finding out if value is null
</ul>
int length = str.length();//using a null value will throw NullPointerException;
<hr width="50%" align="left">
<font color="red">9.What is the difference between Array and ArrayList?</font><br>
<b>Answer:</b>
<ul>
	<li>The array has a fixed length, whereas the size of ArrayList can grow dynamically as elements are added.
</ul>
ArrayList does not store primitives. If we have to store int elements, each should be wrapped into Integer objects to be stored in ArrayList. This is not the case with Array.
<hr width="50%" align="left">
<font color="red">10.What is a class? How to create an object? If a class is static, can you create an object?</font><br>
<b>Answer:</b> Class encapsulates variables of different types and methods that can be clubbed together.<br>
For example:<br>
Class Student can have all the variables and methods related to a student like name, roll number, marks, subjects chosen etc… When an application wants the details of a Student, an object of this class can be created to fetch all the details of the student.
</font>
</body>
</html>