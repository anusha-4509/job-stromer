<?php
?>
<html>
<head>
<title>Written Test</title>
<body bgcolor = "lightyellow">
<font face="corbel" size="4">
<p align="center">The written round consists of three sections  </p><br>
<table border="0" align="center" cellpadding="5" cellspacing="5">
<tr>
	<td><a href = "amazon_aptitude.php">Quantitative Aptitude</a>
</tr>
<tr>
	<td><a href = "amazon_verbal.php">Verbal Reasoning</a>
</tr>
<tr>
	<td><a href="amazon_coding.php">Coding Round</a>
</tr>
</table>
</font>
</body>
</head>
</html>