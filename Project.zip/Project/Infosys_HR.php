<?php
session_start();
require('connection.php');?>
<html>
<head><title>HR</title></head>
<body>
<h1>HR Interview</h1>
<hr width="50%" align="left">
<font face="verdana" size="3">
<font color="red">1) Tell me about yourself?</font><br>
This is the most famous question for an interviewer and also most difficult to answer this question for the candidate. This question puts all the pressure on the candidate, and the interviewer relax.<br>
You should alert enough to answer this question. You should start with an easy and confident tone and answer in a proper manner. It should not be scripted. Always remember, you are not giving the interview to a robot so your articulation, your pronunciation of each word should be clear and confident.<br>
A good way:<br>
Analyze your interviewer interests.<br>
Express your most important accomplishments first.<br>
<b>Possible Answer 1</b><br>
"Good morning/afternoon/evening" sir/mam.<br>
First of all, thank you for giving me this opportunity to introduce myself.<br>
My name is Ajeet Kumar.<br>
As far as my education qualification is concerned, I have done MBA with finance stream from Srivenkateswara university in Emerald's P. G. College, Tirupathi, in the year of 2014.<br>
I had completed B.tech from N.I.T Jaipur in 2012.<br>
I had completed my schooling from G.I.C. Allahabad.<br>
As far as concerned my family, I belong to a middle-class family. My father is a Businessman, and my Mother is a homemaker. My brother is preparing for civil services.<br>
I am good in programming languages C, C++, and Java and very much interested in HTML, CSS, ASP. Net and SQL.<br>
My strength is self-confidence, positive attitude, hard work.<br>
My weakness is: I can easily believe every one.<br>
My hobbies are: Watching news channels, Playing volleyball, Listening to music.<br>
<b>Possible Answer 2</b><br>
"Good morning/afternoon/evening" sir/mam, it's my pleasure to introduce myself. I am Anshika Bansal. I belong to Meerut. I have done my B.Tech in CSE from Lovely Professional University.<br>
While coming to my family members, there are 4 members including me. My father is a doctor, and any mother is a teacher. My younger sister will appear her 12th CBSE board exam this year.<br>
Now coming to me, I am sweet smart, confident, and hardworking person. I am a cool hearted person, so usually see every difficulty with a positive side and keep myself always smiling which makes me stronger even more.<br>
I can carry out any task assigned to me without hesitation.<br>
My hobbies are dancing, Internet surfing, playing Chess, listening to music, watching the news channel. In my spare time, I like to read news on my phone and traveling to my hometown.<br>
Thank you for giving this opportunity to introduce myself.<br>
<b>Possible Answer 3</b><br>
"Good morning/afternoon/evening" sir/mam, it's my pleasure to introduce myself. I am Anshika Bansal. I belong to Meerut. I have done my B.Tech in CSE from Lovely Professional University.<br>
I am carrying 5 years of experience at top Wall Street Companies. In my recent company, I led the development of an award-winning new trading platform. I can survive in a fast-paced environment.<br>
Now I am looking for a chance to apply my technical expertize and my creative problem-solving skills at an innovative software company like yours.
 <hr width="50%" align="left">
<font color="red">2) Why are you applying for this job? (or) Why this role attract you?</font><br>
By this question, the interviewer wants to know that:
<ul type="circle">
	<li>If you fully understand what the job entails
	<li>How well you might match their requirement
	<li>What appeals to you most about this job
</ul>
Before answering this question, take your own time an answer in the way that convinces the interviewer. Explain your qualities according to the above-stated points.<br>
<b>Possible Answer 1</b><br>
I have applied for this vacancy because it is an excellent match for my skills and experience. This role is exactly the sort of role I am currently targeting, and I am confident I will be able to make a major contribution.<br>
<b>Possible Answer 2</b><br>
 Sir, it's a great privilege to work in a reputed company like yours. When I read about your requirement, I found that my skills are matching with them. Through this role, I can show my technical skills to contribute to the company growth.
<hr width="50%" align="left"> 
<font color="red">3) Would you like to work overtime or odd hours?</font><br>
You should become very honest to answer this question. Don't tell a lie or compromise to get the job only. If you don't have any problem, you can answer like this:<br>
 I know that in the company being asked to work for an extended number of hours comes with a good reason, so I am ok with it. It an extra effort means I am doing something for the company, I'll be happy to do it. 
<hr width="50%" align="left"> 
<font color="red">4) What is more important to you: the money or the work?</font><br>
This is a very tricky question. The work should always be more important than the money. This frame of mind is good for you(at least at the time of interview).<br>
<b>Possible Answer 1</b><br>
"Money is always important, but the work is most important for me."<br>
<b>Possible Answer 2</b><br>
"I would say that work is more important. If we work and achieve Company goals then obviously money would follow. I believe work to be prior."<br>
<b>Possible Answer 3</b><br>
"Work is more important for me. Working just for money may not be fulfilled if I don't feel satisfied with my job. My work makes me stay productive, and money would naturally come along well."<br>
<b>Possible Answer 4</b><br>
"I think money probably matters to me about as much as it does to anyone. It's vital and necessary for us to live and prosper but, at the same time, it's not my single most important driving force. I believe that money is rewarded for work."
<hr width="50%" align="left"> 
<font color="red">5) What do you know about this organization?</font><br>
You should fully aware of that organization where you are going for an interview, so check the history, present structure and working style of that organization. Check the company's website, Facebook, Twitter, Google+, LinkedIn pages to gather the information.<br>
<b>Possible Answer 1</b><br>
We all know that it is one of the fastest growing infrastructure company in India. The facilities provided to the employee is best. People feel proud to be the part of your company as the company provides full support to their employees in professional front. The working environment of this company is decent. It has crossed the branches in the world also. And I was in search of this type of company.<br>
<b>Possible Answer 2</b><br>
We all know that this company is India's no.1 company for development. I was delighted to see on your company website that your employees are talking about how great it is to work for your company. Now these days, so many people seem to hate the company where they work for one reason or another. It's great to see that your employees are proud to talk about how much they love their company and jobs.
<hr width="50%" align="left"> 
<font color="red">6) Why did you leave your last job?</font><br>
You should be very careful with this question. Avoid trashing other employers and making a statement like "I need more money". Instead of this, you can say that:<br>
Sir, it's a career move. I have learned a lot from my last job, but now I am looking for new challenges to broaden my horizons and to gain a new skill-set.
<hr width="50%" align="left"> 
<font color="red">7) Why should we hire you?</font><br>
Tell your qualifications and highlight that points which makes you unique.<br>
<b>Possible Answer 1</b><br>
"I believe that everyone starts with a beginning, I need a platform to prove my abilities and skills. I think your company is the right place to explore my abilities. I need to be a part of your growth. I will do my level best."<br>
<b>Possible Answer 2</b><br>
"As a fresher, I need a platform to prove my ability. If I will be a part of your company, I'll put my effort and strength to uplift your company. None is born with experience, and if you hire me, I will get professional experience through your company."<br>
<b>Possible Answer 3</b><br>
"Sir, as I am a fresher, I have theoretical knowledge, but I need a platform where I can implement my knowledge in the practical field. I am ensuring you that I will put all my efforts for the good progress of the organization. As a fresher, I have no preset mind regarding work culture in an organization, and this will help me to adapt the working culture of your company very easily. Being punctual and regular, I can finish the work giving to me on time and try my best to fulfill all the needs of the company."<br>
<b>Possible Answer 4</b><br>
"I have a good experience in that particular field (field of your specialization), and I think my talents will be a big contribution to the continuing pursuit of excellence of your company."
 <hr width="50%" align="left">
<font color="red">8) What are your salary expectations?</font><br>
Don't ask your salary in exact numbers, instead of this show your commitment to the job itself.<br>
<b>Possible Answer 1</b><br>
I am more interested in the role than the pay, and I expect to be paid appropriate money for this role based on my experience. As you also know that the high cost of living here in Delhi.<br>
<b>Possible Answer 2</b><br>
 As I am fresher, Salary is not an issue for me. Learning and gaining experience is my major priority. As your company is one of the most reputed company, I just accept the salary offered by you is the best in the industry.<br>
<b>Possible Answer 3</b><br>
As of now, I haven't thought much about it. I am more focused on learning the requirements for this position that I am applying for.
 <hr width="50%" align="left">
<font color="red">9) Assume you are hired, then how long would you expect to work for us?</font><br>
<b>Possible Answer 1</b><br>
"I will do my best for the growth of your company as long as I have the career growth, job satisfaction, respect and a healthy environment, then I don't need to change my company."<br>
<b>Possible Answer 2</b><br>
"I will work with the company as long as my presence benefits the company and I get ample opportunity to grow and develop both professionally and monetarily."<br>
<b>Possible Answer 3</b><br>
"Everyone looks for a bright future, healthy work environment, good salary, job satisfaction and I am pretty sure that your company gives such things, so I don't need to change the company."<br>
<b>Possible Answer 4</b><br>
"I will work with the company as long as my presence benefits both the company and mine in parallel. So your company gains good results, and I can be in a good position to improve my skills."
 <hr width="50%" align="left">
<font color="red">10) How would you rate yourself on a scale of 1 to 10?</font><br>
<b>Possible Answer 1</b><br>
 I will rate myself 8 out of 10 because I would never like to think that there should be a room left for putting in more efforts. That thought will create an interest in learning the things. Thank you very much for giving me this wonderful opportunity.<br>
<b>Possible Answer 2</b><br>
I will answer this question based on some parameters. As far as hard work is concerned, I will rate myself as 8 because there should always be a scope to increase our skills which will create an interest in learning the things. When it comes to creativity, I would like to rate myself as 9. In the past, I have designed banners and brochures which were appreciated by the clients. To talk about patience, I will tag myself with 6 because I am an entry-level professional. Same as personal life, even professional life needs more experience for more patience. That is probably why in most companies, senior management looks more patient than entry level or even middle level. Overall, I would rate myself as 8 on a scale of 1 to 10. 
</font>
</body>
</html>