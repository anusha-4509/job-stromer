<?php
session_start();
require('connection.php');?>
<html>
<head><title>Python</title></head>
<body>
<h1>Python</h1>
<hr width="50%" align="left">
<font face="verdana" size="3">
<font color="red">1. What is Python?</font><br>
Python is a high-level, interpreted, interactive and object-oriented scripting language that is used to create user interface applications for web development (server side), software development, mathematics, operation and so on.<br>
Python is a general-purpose interpreted, interactive, object-oriented programming language.
<hr width="50%" align="left">
<font color="red">2. Why can't I use an assignment in an expression?</font><br>
The reason for not allowing assignment in Python expressions is a common, hard-to-find bug in those other languages, caused by this construct:<br>
if (x = 0) {<br>
...error handling... <br>
}<br>
else {<br>
... code that only works for nonzero x... <br>
}<br>
The error is a simple typo: x = 0, which assigns 0 to the variable x, was written while the comparison x == 0 is certainly what was intended.
<hr width="50%" align="left">
<font color="red">3. Is there a toolto help find bugs or perform static analysis?</font><br>
Pychecker and Pylint are the static analysis tools that help to find bugs in python. Pychecker is an open source tool for static analysis that detects the bugs from source code and warns about the style and complexity of the bug
<hr width="50%" align="left">
<font color="red">4. How do you set a global variable in a function?</font><br>
Normally, when you create a variable inside a function, that variable is local, and can only be used inside that function. To create a global variable inside a function, you can use the global keyword
<hr width="50%" align="left">
<font color="red">5. What are the rules for local and global variables in Python?</font>
<ul>
	<li>In python, the variables referenced inside a function are global.
	<li>When a variable is assigned new value anywhere in the body of a function then it is assumed as local.
	<li>In a function, if a variable ever assigned new value then the variable is implicitly local and explicitly it should be declared as global.
</ul>
<hr width="50%" align="left">
<font color="red">6. How can we create an empty class in Python?</font><br>
In Python, to write an empty class pass statement is used. Pass is a special statement in Python that does nothing. It only works as a dummy statement. However, objects of an empty class can also be created.
<hr width="50%" align="left">
<font color="red">7. What are the key features of Python?</font><br>
Python is a dynamic, high level, free open source and interpreted programming language. It supports object-oriented programming as well as procedural oriented programming. In Python, we don't need to declare the type of variable because it is a dynamically typed language.
<hr width="50%" align="left">
<font color="red">8. What is the difference between list and tuple in Python?</font><br>
One of the most important differences between list and tuple is that list is mutable, whereas a tuple is immutable. This means that lists can be changed, and tuples cannot be changed.
<hr width="50%" align="left">
<font color="red">9. List steps for setting up static files in Django?</font>
<ul>
	<li>set STATIC_ROOT in settings.py
	<li>run python2.7 manage.py collectstatic (or python3.5 or python3.6 as appropriate)
	<li>Set up a Static Files entry on the PythonAnywhere Web tab.
</ul>
<hr width="50%" align="left">
<font color="red">10. What is Dogpile effect?</font><br>
The Dogpile effect occurs when cache expires and websites are hit by numerous requests the same time. Dogpile effect can be prevented using semaphore lock.
</font>
</body>
</html>