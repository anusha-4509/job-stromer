<?php
?>
<html>
<head>
<title>Written Test</title>
<body bgcolor = "lightyellow">
<font face="corbel" size="4">
<p align="center">Wipro will conduct recuritment through an exam for both on campus and off campus drives.The written test will be held online for both drives.Written exam consists of 4 sections.</p><br>
<table border="0" align="center" cellpadding="5" cellspacing="5">
<tr>
	<td><a href = "wipro_verbal.php">Verbal and Analytical</a>
</tr>
<tr>
	<td><a href = "wipro_aptitude.php">Aptitude and Reasoning</a>
</tr>
<tr>
	<td><a href="wipro_coding.php">Coding Round</a>
</tr>
<tr>
	<td><a href="wipro_written.php">Written Communication Test</a>
</tr>
</table>
</font>
</body>
</head>
</html>