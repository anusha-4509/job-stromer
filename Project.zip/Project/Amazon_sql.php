<?php
?>
<html>
<head><title>MySQL</title></head>
<body>
<h1>MySQL</h1>
<font face="verdana" size="3">
<hr width="50%" align="left">
<font color="red"><b>Q1.What are Procedures in MySQL?</b></font><br>
<b>Answer:</b><br>
Procedures (or stored procedures) are subprograms, just like in a regular language, embedded in the database. A stored procedure consists of a name, SQL statement(s) and parameters. It utilises the caching in MySQL and hence saves time and memory, just like the prepared statements.
<br>
<br>
<hr width="50%" align="left">
<font color="red"><b>Q2. What is a trigger in MySQL?</b></font><br>
<b>Answer:</b><br>
A trigger is a table-associated database object in MySQL. It is activated when a specified action takes place.<br>
<br>
A trigger can be invoked after or before the event takes place. It can be used on INSERT, DELETE, and UPDATE. It uses the respective syntax to define the triggers. For example, BEFORE INSERT, AFTER DELETE, etc.
<br>
<br>
<hr width="50%" align="left">
<font color="red"><b>Q3.How to add users in MySQL?</b></font><br>
<b>Answer:</b>
<br>To simply put, the user can be added by using the CREATE command and specifying the necessary credentials. First, log in to the MySQL account and then apply the syntax. Something like this:<br>
<br>
CREATE USER ‘testuser’ IDENTIFIED BY ‘sample password’;<br>
<br>
Users can be granted permissions, by the following commands:<br>
<br>
GRANT SELECT ON * . * TO ‘testuser’;
<br>
<br>
<hr width="50%" align="left">
<font color="red"><b>Q4.What is the core difference between Oracle and MySQL?</b></font><br>
<b>Answer:</b><br>
The core difference is that MySQL works on a single-model database. That means it can only work with one base structure, while Oracle is a multi-model database. It means it can support various data models like graph, document, key-value, etc. <br>
<br>
Another fundamental difference is that Oracle’s support comes with a price tag for industrial solutions. While MySQL is open-source.<br>
<br>
Now this question is one of the MySQL interview questions that should be understood carefully. Because it directly deals with the industry standards and what the company wants.
<br>
<br>
<hr width="50%" align="left">
<font color="red"><b>Q5. What is CHAR and VARCHAR in MySQL?</b></font><br>
<b>Answer</b><br>
Both of them define a string. The core difference is that CHAR is a fixed-length while VARCHAR is variable length. For example, if CHAR(5) is defined, then it needs exactly five characters. If VARCHAR(5) is defined, then it can take at most five characters. VARCHAR can be said to have more efficiency in the usage of memory as it can have dynamic memory allocations. 
<br>
 <br>
<hr width="50%" align="left">
<font color="red"><b>Q6.Which drivers are necessary for MySQL?</b></font><br>
<b>Answer:</b><br>
There are many types of drivers in MySQL. Mostly they are used for connections with different computational languages. Some of them are listed below:<br>
<br>
· PHP Driver<br>
<br>
· JDBC<br>
<br>
· OBDC<br>
<br>
· Python Driver<br>
<br>
· C – Wrapper<br>
<br>
· Perl and Ruby Drivers
<br>
<br>
<hr width="50%" align="left">
<font color="red"><b>Q7. What is a LIKE statement? Explain % and _ in LIKE.</b></font><br>
<b>Answer:</b><br>
 While using filters in commands like SELECT, UPDATE, and DELETE, conditions might require a pattern to detect. LIKE is used to do just that. LIKE has two wildcard characters, namely % (percentage) and _ (underscore). Percentage(%) matches a string of characters, while underscore matches a single character.<br>
<br>
For example, %t will detect trees and tea both. However, _t will only detect one extra character, i.e., strings like ti or te. 
<br>
<br>
<hr width="50%" align="left">
<font color="red"><b>Q8. How to convert timestamps to date in MySQL?</b></font><br>
<b>Answer:</b><br>
It is a rather simple question that requires knowledge on two commands, like DATE_FORMAT and FROM_UNIXTIME.<br>
<br> 
DATE_FORMAT(FROM_UNIXTIME(`date_in_timestamp`), ‘%e %b %Y’) AS ‘date_formatted’
<br>
<br>
<hr width="50%" align="left">
<font color="red"><b>Q9.Can a query be written in any case in MySQL?</b></font><br>
<b>Answer:</b><br>
This MySQL interview question often confuses people who are just getting started with MySQL. Although most of the time, the queries are written in capital or some in small letters, there is no such case sensitivity to MySQL queries.<br>
<br>
For example, both create table tablename and CREATE TABLE tablename, works fine.<br>
<br>
However, if required, it is possible to make the query case sensitive by using the keyword BINARY. <br>
<br>
This MySQL interview question can be tricky, especially when asked to make the query case-sensitive explicitly. 
<br>
<br>
<hr width="50%" align="left">
<font color="red"><b>Q10.How to save images in MySQL? </b></font><br>
<b>Answer:</b><br>
Images can be stored in the MySQL database by converting them to BLOBS. But it is not preferred due to the large overhead it creates. Plus, it puts unnecessary load on the RAM while loading the entire database. It is hence preferred to store the paths in the database and store the images on disk. <br>
<br>

</font>
</body>
</html>