<?php
?>
<html>
<head>
<title>quantitative aptitude</title>
</head>
<body>
<h1>Amazon Quantitative Aptitude Interview Questions</h1>
<hr width="50%" align="left">
<font face="verdana" size="3">
</font>
</body>
</html>