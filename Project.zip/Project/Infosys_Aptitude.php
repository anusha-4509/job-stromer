<?php
session_start();
require('connection.php');?>
<html>
<head><title>Aptitude</title></head>
<body>
<h1>Aptitude Questions on Mathematical Ability and Logical Reasoning </h1>
<hr width="50%" align="left">
<font face="verdana" size="3">
Q1: Anita goes to College at 20 km/h and reaches college 4 minutes late. Next time she goes at 25 km/h and reaches the college 2 minutes earlier than the scheduled time. What is the distance of her school? 
<ol type="A">
	<li>16 km 
	<li>12 km 
	<li>15 km 
	<li>10 km 
</ol>
<b>Answer:</b>D<br>
<b>Explanation:</b>
Speed = Distance/ time <br>
The distance is common here. So let's equate the distances. <br>
Case of going late <br>
D = 20 * (T + 4/60) ----- Equation 1 <br>
Case of going early <br>
D = 25 * (T-2/60) ------ Equation 2 <br>
Equating the Distances, <br>
20 * (T + 4/60) = 25 * (T-2/60) <br>
20T + 80/60 = 25T - 50/60 <br>
130/60 = 5T <br>
T = 130/(60 * 5) = 13 / 30 <br>
Now, let's calculate the distance from Equation 1. <br>
D = 20 * (13/30 + 4/60) = 20 * (26/60 + 4/60) = 20 * 30/60 <br>
Therefore, D = 10 km
<hr width="50%" align="left">
Q2: A truck covers a distance of 376 km at a certain speed in 8 hours. How much time would a car take at an average speed which is 18 kmph more than that of the speed of the truck to cover a distance which is 14 km more than that travelled by the truck ?
<ol type="A">
	<li>6 hours 
	<li>5 hours 
	<li>7 hours 
	<li>8 hours 
</ol>
<b>Answer:</b> A <br>
<b>Explanation:</b> <br>
Speed of the truck = Distance/time = 376/8 = 47 kmph <br>
Now, speed of car = (speed of truck + 18) kmph = (47 + 18) = 65 kmph <br>
Distance travelled by car = 376 + 14 = 390 km <br>
Time taken by car = Distance/Speed = 390/65 = 6 hours.
<hr width="50%" align="left">
Q3. Two cars namely A and B start simultaneously from a certain place at the speed of 40 kmph and 55 kmph, respectively. The car B reaches the destination 2 hours earlier than A. What is the time taken by A to reach the destination? 
<ol type="A">
	<li>8 hours 12 minutes 
	<li>6 hours 15 minutes 
	<li>7 hours 20 minutes 
	<li>7 hours 12 minutes 
</ol>
<b>Answer:</b> C <br>
<b>Explanation: </b><br>
Let the time taken by car A to reach destination is T hours <br>
So, the time taken by car B to reach destination is (T-2) hours. <br>
S1T1 = S2T2 <br>
=> 40(T) = 55 (T-2) <br>
=> 40T = 55T-110 <br>
=> 15T = 110 <br>
T = 7 hours 20 minutes <br>
<hr width="50%" align="left">
Q4. Out of 7 consonants and 4 vowels, how many words of 3 consonants and 2 vowels can be formed? 
<ol type="A">
	<li>24400 
	<li>21300 
	<li>210 
	<li>25200 
</ol>
<b>Answer:</b> D <br>
<b>Explanation: </b>
Number of ways of selecting 3 consonants from 7 = 7C3 <br>
Number of ways of selecting 2 vowels from 4 = 4C2 <br>
Number of ways of selecting 3 consonants from 7 and 2 vowels from 4 = 7C3 x 4C2 = (7x6x53x2x1)x(4x32x1) = 210 <br>
It means we can have 210 groups where each group contains total 5 letters (3 consonants and 2 vowels). <br>
Number of ways of arranging 5 letters among themselves =5!=5x4x3x2x1=120=5!=5x4x3x2x1=120 Hence, required number of ways =210x120 = 25200
<hr width="50%" align="left">
Q5: Twelve people are sitting in two parallel rows containing six people each such that they are equidistant from each other. In row 1: P, Q, R, S, T and V are seated and all of them are facing south. In row 2: A, B, C, D, E and F are seated and all of them are facing North. Therefore in the given seating arrangement, each member is seated in a row faces another member of the other row. 
<ul>
	<li>Either S or Q sits at an extreme end of the line. 
	<li>S sits third to the right of Q. 
	<li>The one who faces Q sits second to the right of E. 
	<li>The one who faces Q sits second to the right of E. 
	<li>Two people sit between B and F. 
	<li>Neither B nor F sits at an extreme end of the line. 
	<li>The immediate neighbour of B faces the person who sits third to the left of P. 
	<li>R and T are immediate neighbours 
	<li>C sits second to the left of A 
	<li>T does not face the immediate neighbour of D. 
</ul>
Who amongst the following sit at the extreme ends of the rows?
<ol type="A" >
	<li>S, D 
	<li>Q, A 
	<li>V, C 
	<li>P, D 
	<li>Q, F 
</ol>
<b>Answer:</b>D <br>
<b>Explanation:</b>
From the first three conditions, two solutions are possible <br>
S _ _ Q _ _ <br>
_ E _ _ _ _ <br>
Or <br>
_ _ S _ _ Q <br>
_ _ _ E _ _ <br>
As B and F have two people between them and neither are at the extremes, they must by in the second and fifth place. Hence, we can rule out configuration 1. <br>
From the 6th condition, B should be fifth from left and F second. <br>
Thus, we get <br>
P _ S _ _ Q<br>
 _ F _ E B _ <br>
As C is second to the left of A, C must be first from left and A third. Hence, D is last from left. Thus, we can place all the people as follows <br>
P V S T R Q <br>
C F A E B D <br>
Hence, P and D are at extreme ends. <br>
<hr width="50%" align="left">
Q6: Twelve people are sitting in two parallel rows containing six people each such that they are equidistant from each other. In row 1: P, Q, R, S, T and V are seated and all of them are facing south. In row 2: A, B, C, D, E and F are seated and all of them are facing North. Therefore in the given seating arrangement, each member is seated in a row faces another member of the other row. 
<ul>
	<li>Either S or Q sits at an extreme end of the line. 
	<li>S sits third to the right of Q. 
	<li>The one who faces Q sits second to the right of E. 
	<li>The one who faces Q sits second to the right of E. 
	<li>Two people sit between B and F. 
	<li>Neither B nor F sits at an extreme end of the line. 
	<li>The immediate neighbour of B faces the person who sits third to the left of P. 
	<li>R and T are immediate neighbours 
	<li>C sits second to the left of A 
	<li>T does not face the immediate neighbour of D. 
</ul>
Who amongst the following faces S? 
<ol type="A">
	<li> A 
	<li>B 
	<li>C 
	<li>D 
	<li>F 
</ol>
<b>Answer:</b> A <br>
<b>Explanation: </b><br>
From the first three conditions, two solutions are possible <br>
S _ _ Q _ _<br>
 _ E _ _ _ _ <br>
Or<br>
 _ _ S _ _ Q <br>
_ _ _ E _ _ <br>
As B and F have two people between them and neither are at the extremes, they must by in the second and fifth place. Hence, we can rule out configuration 1. <br>
From the 6th condition, B should be fifth from left and F second. <br>
Thus, we get <br>
P _ S _ _ Q<br>
 _ F _ E B _ <br>
As C is second to the left of A, C must be first from left and A third. Hence, D is last from left. Thus, we can place all the people as follows <br>
P V S T R Q <br>
C F A E B D <br>
Hence, it is evident that S faces A. Option A is correct. 
<hr width="50%" align="left">
Q7: X and Y start from the same point and run around a circular stadium, whose circumference is 2800 m, at the rate of 250 m and 350 m per minute respectively in the opposite direction. They will meet each other in?
<ol type="A"> 
	<li>14/3 min 
	<li>16/3 min 
	<li>12/5 min 
	<li>18/5 min 
	<li>11/3 min 
</ol>
<b>Answer:</b> A <br>
<b>Explanation: </b><br>
Let X cover 'x' meters while he meets Y. <br>
Therefore, <br>
7x=14,000 - 5x <br>
x=3500/3 m <br>
Required time = 14/3 min. <br>
<hr width="50%" align="left">
Q8: A work is done by 30 workers not all of them have the same capacity to work. Every day exactly 2 workers, do the work with no pair of workers working together twice. Even after all possible pairs have worked once, all the workers together works for six more days to finish the work. Find the number of days in which all the workers together will finish the work? 
<ol type="A">
	<li>22 days 
	<li>20 days 
	<li>24 days 
	<li>35 days 
	<li>32 days 
</ol>
<b>Answer:</b> D <br>
<b>Explanation: </b><br>
30 workers work in pairs, with no same pair of workers working together twice 
<hr width="50%" align="left">
Q 9: (x-2) person can do a work in x days and (x+7) person can do 75% of the same work in (x-10)days. Then in how many days can (x+10) person finish the work?
<ol type="A"> 
	<li>27 days 
	<li>12 days 
	<li>25 days 
	<li>18 days 
	<li>None of these 
</ol>
<b>Answer:</b> B <br>
<b>Explanation: </b><br>
3/4 * (x-2)x = (x+7)(x-10) <br>
x - 6x - 280 = 0 <br>
x = 20; x = -14 <br>
(x-2)x = 18 * 20 = 360 <br>
360 = 30 * y <br>
y = 12 days <br>
<hr width="50%" align="left">
Q 10: Sruthi, Swetha and Swati together can cut 216 Apples of the same size in 3 hours. Number of Apples cut by Sruthi in 9 hours is same as the number of Apples cut by Swati in 7 hours. In one hour, Swati can cut as many Apples more than Swetha as Swetha can cut more than Sruthi.Then the number of Apples cut by Swetha in one hour? 
<ol type="A">
	<li>21 
	<li>24 
	<li>27 
	<li>29 
</ol>
<b>Answer:</b> B <br>
<b>Explanation: </b><br>
U+v+W = 72 <br>
9U = 7W <br>
W-V = V-U <br>
V = 24
</font>
</body>
</html>