<?php
session_start();
require('connection.php');?>
<html>
<head><title>DBMS</title></head>
<body>
<h1>DBMS</h1>
<hr width="50%" align="left">
<font face="verdana" size="3">
<font color="red">1.What is Database Management System?</font><br>
A Database Management System is a software system is used for creating and managing databases. DBMS makes it possible for the end-user to create and maintain databases. DBMS provides an interface between the end-user/application and the databases.
<hr width="50%" align="left">
<font color="red">2.Enlist different advantages of DBMS.</font><br>
The list of several advantages of Database Management System:
<ul>
	<li>Improved data security.
	<li>Improved data sharing.
	<li>Better data integration.
	<li>Minimized data inconsistency.
	<li>Improved data access.
	<li>Improved decision making.
	<li>Increased end-user productivity.
</ul>
<hr width="50%" align="left">
<font color="red">3.What do you mean by Object-Relational DBMS?</font><br>
The object-relational database (ORD) is a database management system (DBMS) that is composed of both an object-oriented database (OODBMS) and a relational database (RDBMS). ORD supports the essential components of an object-oriented database model in its schemas and the query language used, such as inheritance, classes, and objects.<br>
An object-relational database is also known as an object-relational database management system (ORDBMS).
<hr width="50%" align="left">
<font color="red">4.What is database Schema?</font><br>
It is a set of formulas (sentences) called integrity constraints imposed on a database.
<hr width="50%" align="left">
<font color="red">5. Mention the different languages present in DBMS</font><br>
The different languages present in DBMS are as follows:
<ul>
	<li>DDL(Data Definition Language) - Consists of commands which are used to define the database.
	<li>DML(Data Manipulation Language) - Consists of commands which are used to manipulate the data present in the database.
	<li>DCL(Data Control Language) - Consists of commands which deal with the user permissions and controls of the database system.
	<li>TCL(Transaction Control Language) - Consist of commands which deal with the transaction of the database.
</ul>
<hr width="50%" align="left">
<font color="red">6. What do you understand by query optimization?</font>
Query optimization is the phase that identifies a plan for evaluation query that has the least estimated cost. This phase comes into the picture when there are a lot of algorithms and methods to execute the same task.<br>
The advantages of query optimization are as follows:
<ul>
	<li>The output is provided faster
	<li>A larger number of queries can be executed in less time
	<li>Reduces time and space complexity
</ul>
<hr width="50%" align="left">
<font color="red">7. Do we consider NULL values the same as that of blank space or zero?</font><br>
A NULL value is not at all same as that of zero or a blank space. The NULL value represents a value which is unavailable, unknown, assigned or not applicable whereas zero is a number and blank space is a character.
<hr width="50%" align="left">
<font color="red">8. What is concurrency control?</font><br>
This is a process of managing simultaneous operations in a database so that database integrity is not compromised. The following are the two approaches involved in concurrency control:
<ul>
	<li>Optimistic approach - Involves versioning
	<li>Pessimistic approach - Involves locking
</ul>
<hr width="50%" align="left">
<font color="red">9. What are the ACID properties in DBMS?</font><br>
ACID stands for Atomicity, Consistency, Isolation, Durability. It is used to ensure that the data transactions are processed reliably in a database system. 
<ul>
	<li>Atomicity: Atomicity refers to those transactions which are completely successful or failed. Here each transaction refers to a single logical operation of a data. So, even if one part of any transaction fails, the entire transaction fails and the database state is left unchanged.
	<li>Consistency: Consistency ensures that the data must meet all the validation rules. In simple words,  you can say that your transaction never leaves the database without completing its state.
	<li>Isolation: The main goal of isolation is concurrency control.
	<li>Durability: Durability means that if a transaction has been committed, it will occur whatever may be the scenario.
</ul>
<hr width="50%" align="left">
<font color="red">10. What is normalization and what are the different types of normalization?</font><br>
The process of organizing data to avoid any duplication of data and redundancy is known as Normalization. There are many successive levels of normalization which are known as normal forms. Each consecutive normal form depends on the previous one. The following are the first three normal forms. Apart from these, you have higher normal forms such as BCNF. 
<ul>
	<li>First Normal Form (1NF) - No repeating groups within rows
	<li>Second Normal Form (2NF) - Every non-key (supporting) column value is dependent on the whole primary key.
	<li>Third Normal Form (3NF) - Dependent solely on the primary key and no other non-key (supporting) column value.
</ul>
</font>
</body>
</html>