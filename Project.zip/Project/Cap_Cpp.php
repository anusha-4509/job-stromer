<?php
?>
<html>
<head><title>C++</title></head>
<body>
<h1>C++</h1>
<hr width="50%" align="left">
<font size="3" face="verdana">
<font color="red"><b>Q1. Briefly explain the concept of Inheritance in C++.</b></font><br>
<b>Answer:</b> <br>
When C++ allows classes to inherit some of the commonly used states and behaviour from other classes, it is known as inheritance.
<hr width="50%" align="left">
<font color="red"><b>Q2. Define C++ </b></font><br>
<b>Answer:</b> <br>
C++ could be defined as a computer programming language that is a superset of C wherein additional features are made in the C language.
<hr width="50%" align="left">
<font color="red"><b>Q3. Can we call C++ as OOPS? and Why?</b></font><br>
<b>Answer:</b><br>
 Yes, we can call C++ as OOPS. Object-Oriented Programming System means that it provides an application of various concepts including data binding, polymorphism, inheritance, and various others.
<hr width="50%" align="left">
<font color="red"><b>Q4. What is the function of the keyword "Volatile"?</b></font><br>
<b>Answer:</b><br>
 Volatile is a function that is used to declare whether the particular variable is volatile and thereby directs the compiler to change the variable externally. This way helps in avoiding the compiler optimization on the variable reference.
<hr width="50%" align="left">
<font color="red"><b>Q5. Define storage class in C++? Name some?</b></font><br>
<b>Answer:</b><br>
 A storage class in C++ specifically resembles that of life or even the scope of symbols, including the variables, functions, etc. Some of the storage classes in C++ are mutable, auto, static, extern, register, etc.
<hr width="50%" align="left">
<font color="red"><b>Q6. Explain 'this' pointer?</b></font><br>
<b>Answer:</b> <br>
The 'this' pointer could be referred to as a constant pointer that holds the memory address of the current object. It passed off as a hidden argument to all the nonstatic member function calls and is available as a local variable within the body of all the nonstatic functions. The static member functions can be called even without any object, i.e. with the class name, which is why the 'this' pointer is not available for them. 
<hr width="50%" align="left">
<font color="red"><b>Q7. Why do we need the Friend class and function?</b></font><br>
<b>Answer:</b> <br>
At times there is a need for allowing a particular class to access private or protected members of a class and to do so we make use of a friend class, that is capable of accessing the protected as well as the private members of the class in which it is declared as a friend. A friend function, on the other hand, can access private and protected class members. It could either be a global function or a method of some class.
</font>
</body>
</html>