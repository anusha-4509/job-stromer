<?php
?>
<html>
<head><title>Verbal</title></head>
<body>
<h1>Verbal</h1>
<font face="verdana" size="3">
<hr width="50%" align="left">
1. Choose the option which is synonymous with the meaning of the word: Angry
<ol type="A">
	<li>Furious
	<li>Pleased
	<li>Precipitous
	<li>Hasty
</ol>
<b>Answer:</b>A <br>
<b>Explanation:</b>Angry means feeling or showing strong annoyance, displeasure or hostility.<br>
<br>
 Meaning of Furious is extremely angry, pleased means feeling or showing pleasure and satisfaction, Precipitous means steep or high and the meaning of Hasty is acting with excessive speed. So looking at the meaning of different words "Furious" is the correct answer.
<hr width="50%" align="left">
2. Choose the option which is synonymous with the meaning of the word: Offbeat 
<ol type="A">
	<li>Ordinary
	<li>Unusual
	<li>Correct
	<li>Compassion
</ol>
<b>Answer:</b>B <br>
<b>Explanation:</b> Offbeat means unconventional or which is not ordinary.<br>
 Meaning of ordinary is: with no special or distinctive features, unusual means something which does not occur commonly or done commonly, compassion means a strong feeling of sympathy and sadness for the suffering of others. So looking at the meaning of different words "Unusual" is the correct answer.
<hr width="50%" align="left">
3. Choose the option which is opposite to the meaning of the word: Fallacy
<ol type="A">
	<li>Delusion
	<li>Hallucination
	<li>Misbelief
	<li>Truth
</ol>
<b> Answer:</b> D <br>
<b>Explanation:</b> Fallacy means a mistaken belief. Meaning of delusion is the act of tricking or deceiving someone; hallucination means an experience involving the apparent perception of something not present, misbelief means wrong or false belief or opinion. Truth is a fact or belief. So looking at the meanings of different words, "Truth" has the opposite meaning.
<hr width="50%" align="left">
 4. Choose the option which is opposite to the meaning of the word: Regression
<ol type="A">
	<li>Advancement
	<li>Reversion
	<li>Evolution
	<li>Overturn
</ol>
<b>Answer:</b> A <br>
<b>Explanation:</b> Regression means to return to a former state Meaning of Advancement is progression to a higher stage of development, reversion means a return to a previous state, and evolution means the gradual development of something. Meaning of Overturn is to abolish. Looking at the meanings of different words, "Advancement" has the opposite meaning.
<hr width="50%" align="left">
5. Choose the option which best expresses the below-given sentence in Active/Passive voice Rajesh said, "The teacher was teaching".
<ol type="A">
	<li>Rajesh said that the teacher was teaching
	<li>Rajesh said that the teacher has been teaching
	<li>Rajesh said that the teacher had been teaching
	<li>None of the above
</ol>
<b>Answer:</b> C<br>
<b>Explanation:</b> The given sentence is in active voice; we need to convert it into passive voice. "The teacher was teaching" is in past continuous tense. To convert it to passive voice, past participle form has to be used, so "the teacher had been teaching" will be used in passive voice. The object of the active verb becomes the subject of the passive verb.
<hr width="50%" align="left">
 6. Choose the option which best expresses the below-given sentence in Active/Passive voice Thrice a month, Rajesh cleans the room.
<ol type="A">
	<li>Thrice a month, the room is cleaned by Rajesh
	<li>Thrice a month, the room is being cleaned by Rajesh
	<li>Thrice a month, the room was cleaned by Rajesh
	<li>None of the above
</ol>
<b>Answer:</b> A<br>
<b> Explanation:</b> The given sentence is in active voice, we need to convert it into passive voice. "Thrice a month, Rajesh cleans the room" is in Simple present. To convert it to passive voice, past participle form of the verb has to be used. The object of the active verb becomes the subject of the passive verb.
<hr width="50%" align="left">
7. Choose the correct preposition and fill in the blanks: The father said to his child, "You must be back ____________ eight o'clock." 
<ol type="A">
	<li>in
	<li>on
	<li>by
	<li>to
</ol>
<b>Answer:</b> C <br>
<b>Explanation:</b>Preposition 'by' is used to denote: not later than the time mentioned; before.
<hr width="50%" align="left">
 8. Choose the correct preposition and fill in the blanks: He worked out at the gym from 8PM ________9PM.
<ol type="A">
	<li>since
	<li>for
	<li>till
	<li>before
</ol>
<b>Answer:</b> C<br>
<b>Explanation:</b> Till is used to denote time "up to".
</font>
</body>
</html>