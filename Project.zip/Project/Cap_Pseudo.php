<?php
?>
<html>
<head>
<title>Pseudocode</title>
</head>
<body>
<h1>Pseudo code</h1>
<hr width="50%" align="left">
<font face="verdana" size="3">
Q1. What will be the output of the following pseudocode?<br>
Integer i<br>
 Set i = 3<br>
Do<br>
 print i + 3 <br>
i = i - 1<br>
 while(i not equals 0) <br>
end while<br>
<br>
 [Note: A do-while loop is a control flow statement that executes a block of code at least once, and then repeatedly executes the given Boolean condition at the end of the block]<br>
<br>
<ol type="A">
	<li>6 6 6
	<li>6 5 6
	<li>5 5 5
	<li>6 5 4
</ol>
<b>Answer:</b>D<br>
<b>Explanation:</b> In this program, one variable declared as i, and the value initialized as 3. We are moving with do-while(Do while will execute the statement once and then it will check the condition). <br>
<br>
Step 1: It will print i+3, here i value is 3. So i+3 is 6. On the next line, i will be decremented by 1. Then checking the conditions in do-while() i!=0. Here updated i value is 2 (2!=0),so condition is true. The loop continues. <br>
<br>
Step 2: It will print i+3, here the updated i value is 2. So i+3 is 5. On the next line, i will be decremented by 1. Then checking the conditions in do-while() i!=0. <br>
<br>
Here updated i value is 1 (1!=0),so condition gets true. The loop continues <br>
<br>
Step 3: It will print i+3, here the updated i value is 1. So i+3 is 4. On the next line, i will be decremented by 1. Then check the condition in do-while() i!=0. Here updated i value is 0 (0!=0),so condition gets false. Thus the loop gets terminated!<br>
<hr width="50%" align="left">
Q2. What would be the output of the following pseudocode?<br>
 Integer a <br>
String str1 <br>
Set str1 = "goose" <br>
a = stringLength(str1)<br>
 Print (a ^ 1)<br>
<br>
 [Note- string-length(): string-length() function counts the number of characters in a given string and return the integer value. <br>
<br>
^ is the bitwise exclusive OR operator that compares each bit of its first operand to the corresponding bit of its equal operand. If one bit is 0 and the other bit is 1, the corresponding result bit is set to 1. Otherwise, the corresponding result bit is set to 0] <br>
<ol type="A">
	<li>0
	<li>4
	<li>5
	<li>3
</ol>
<b>Answer:</b> B<br>
<b>Explanation:</b> There are two variables a and str1. Value initialized for str1 is "goose". On the next line, we are finding the length of str1 that is 5. Finally, printing the output of a bitwise exclusive OR operator with 1. And the answer is 4.<br>
<hr width="50%" align="left">
Q3. What would be the output of the following pseudocode?<br>
 Integer a, b, c<br>
 Set a = 8, b = 51, c = 2 <br>
c = (a ^ c)^ (a) <br>
b = b mod 4<br>
 Print a + b + c <br>
<br>
[Note- mod finds the remainder after the division of one number by another. For example, the expression "5 mod 2" would evaluate to 1 because 5 divided by 2 leaves a quotient of 2 and a remainder of 1.<br>
<br>
^ is the bitwise exclusive OR operator that compares each bit of its first operand to the corresponding bit of its equal operand. If one bit is 0 and the other bit is 1, the corresponding result bit is set to 1. Otherwise, the corresponding result bit is set to 0].
<ol type="A">
	<li>13
	<li>17
	<li>26
	<li>16
</ol>
<b>Answer:</b> A <br>
<b>Explanation:</b> There are three variables a, b and c declared. Value initialized for a is 8, b is 51 and c is 2. <br>
When we do a bitwise exclusive OR of (8^2), the answer is 10. Again 10 bitwise exclusive OR of a i.e (10 ^ 8) is 2, which will be stored in variable c.<br>
 Then taking modulo operation for b by 4 (b%4) the answer is 3<br>
 Finally adding all the updated values of a,b, and c (8+2+3 ) and the output of Pseudocode is 13.
<hr width="50%" align="left">
Q4. Consider an array A = {1, 2, 4, 5, 6, 11, 12} and a key which is equal to 10. <br>
How many comparisons would be done to find the key element in the array using the binary search ?
<ol type="A">
	<li>5
	<li>1
	<li>2
	<li>3
</ol>
<b>Answer:</b>D <br>
<b>Explanation:</b> There is an Integer Array A = {1, 2, 4, 5, 6, 11, 12} and the key value is 10.
<hr width="50%" align="left">
Q5. What would be the output of the following pseudocode? <br>
Integer i, j, k<br>
 Set k = 8 <br>
for(each i from 1 to 1) <br>
for(each j from the value of i to 1) <br>
print k+1 <br>
end for <br>
end for
<ol type="A">
	<li>2
	<li>9
	<li>7
	<li>8
</ol>
<b>Answer:</b> B <br>
<b>Explanation:</b> There are three variables i, j, and k declared. Value initialized for k is 8, In this code, we are moving with nested for loop.<br>
<br>
 Here I value is 1, for loop will check the condition i<=1 condition gets true. Now, moving with inner for loop j value will be 1 condition gets true j<=1.so, it prints K+1. Then j value will be incremented by 1(2<=1) condition get false.<br>
 So the answer is 9.
<hr width="50%" align="left">
Q6.What will be the output of the following pseudocode? <br>
Integer a, b <br>
Set a = 15, <br>
b = 7 <br>
a = a mod (a - 3) <br>
b = b mod (b - 3)<br>
 a = a mod 1<br>
 b = b mod 1 <br>
Print a + b
<ol type="A">
	<li>15
	<li>7
	<li>2 
	<li>0
</ol>
[Note-mod finds the remainder after the division of one number by another.<br>
 For example, the expression "5 mod 2" leaves a quotient of 2 and a remainder of 1] <br>
<b>Answer:</b> 0<br>
<b>Explanation:</b> There are two variables a and b declared. Value initialized for a is 15 and b is 7. Taking mod operation for a by 12(a%12) and the answer is 3 will stored in a.<br>
The next mod operation for b is 7 mod (7%4). The answer is 3 will be stored in b.<br>
 The next line takes the updated value of a and mods it by 1(3%1). Then the answer becomes 0 will be stored in a. <br>
The next line takes the updated value of b mod by 1 (3%1) then the answer is 0. Finally adding all the updated values of a and b (0+0 ) and the output of Pseudocode is 0.<br>
<hr width="50%" align="left">
Q7. What will be the output of the following pseudocode?<br>
Integer a, b, c <br>
Set b = 5, a = 2, c = 2<br>
 if(b>a && a>c && c>b) <br>
b = a + 1 <br>
Else a = b + 1 <br>
End if <br>
Print a + b + c<br>
<br>
 [Note-&&: Logical AND - The logical AND operator (&&) returns the Boolean value true(or 1) if both operands--. If (x) gets executed if the value if(), i.e., x is not zero]
<ol type="A">
	<li>2
	<li>13
	<li>26
	<li>5
</ol>
<b>Answer:</b> B <br>
<b>Explanation:</b> There are three variables a, b and c declared. Value initialized for a is 2, b is 5 and c is 2.<br>
 Checking the condition using if, b >a and a>c and c>b here if conditions get false. Now else part will execute b value will be incremented by 1 and stored in a, Finally adding all the updated values of a, b and c (6+5+2 ) and the output of Pseudocode is 13.
<hr width="50%" align="left">
Q8. For which of the following applications can you use hashing?
<ol type="1">
	<li> To construct a message authentication code.
	<li>For Timestamping
	<li>For detecting a cycle in a graph
</ol>
Choose the correct answer from the options given below.
<ol type="A">
	<li>Only 1 and 3
	<li>Only 2 and 3
	<li>Only 1
	<li>Only 1 and 2
</ol>
<b> Answer:</b>D<br>
<br>
<b>Explanation:</b> Constructing a message authentication code and Timestamping are the real-time applications for hashing.
<hr width="50%" align="left">
Q9. Consider an array of float. Calculate the difference between the address of the 1st and 4th element, assuming float occupies 4 bytes of memory.
<ol type="A">
	<li>16
	<li>4
	<li>12
	<li>8
</ol>
<b>Answer:</b> C <br>
<b>Explanation:</b> Let's consider the address of elements: 1st element - 1000 - 1003 (4 bytes) 2nd element - 1004 - 1007 (4 bytes) 3rd element - 1008 - 1011 (4 bytes) 4th element - 1012 - 1015 (4 bytes) The difference between the address of the 1st and 4th elements is 12.
<hr width="50%" align="left">
Q10. What is the second part of a node in a linked list that contains the address of the next node called?
<ol type="A">
	<li>data
	<li>pointer
	<li>element
	<li>Link
</ol>
<b>Answer:</b> D <br>
<b>Explanation:</b> The field of each node that contains the address of the next node is usually called the 'link'.
</font>
</body>
</html>