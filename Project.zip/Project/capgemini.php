<?php
?>
<html>
<head>
<title>Capgemini</title>
</head>
<body bgcolor = "lightyellow">
<font face="verdana" size="4">
<p align="center">Capgemini is a French Multinational company headquartered in Paris. IT consulting, Management consulting, Cloud infrastructure & consulting are some of the major services provided by Capgemini. Capgemini Company was established in 1967. Capgemini is one of the best places to work among the other IT companies. Capgemini has nearly 200,000 employees and has offices in around 40 countries. Capgemini India is home to nearly 50% of its employees.
Capgemini Recruitment Process for the 2021 batch consists of the following rounds. The latest rounds in the Capgemini recruitment process this year are given below.
 </p><br>
<table border="0" align="center" cellpadding="5" cellspacing="5">
<tr>
	<td><a href = "cap_writtentest.php">Written Test</a>
</tr>
<tr>
	<td><a href = "cap_technical.php">Technical Interview</a>
</tr>
<tr>
	<td><a href="cap_hr.php">HR Interview </a>
</tr>
</table>
</font>
</body>
</html>