<?php
session_start();
require('connection.php');?>
<html>
<head><title>C++</title></head>
<body>
<h1>C Plus Plus</h1>
<hr width="50%" align="left">
<font face="verdana" size="3">
<font color="red">1. What are the different data types present in C++?</font><br>
The 4 data types in C++ are given below:
<ul>
	<li>Primitive Datatype(basic datatype). Example- char, short, int, float, long, double, bool, etc.
	<li>Derived datatype. Example- array, pointer, etc.
	<li>Enumeration. Example - enum
</ul>
<hr width="50%" align="left">
<font color="red">2. What is operator overloading?</font><br>
Operator Overloading is a very essential element to perform the operations on user-defined data types. By operator overloading we can modify the default meaning to the operators like +, -, *, /, <=, etc. <br>
For example - <br>
The following code is for adding two complex number using operator overloading-<br>
classcomplex{<br>
private:<br>
float r, i;<br>
public:<br>
complex(float r, floati){<br>
this->r=r;<br>
this->i=i;<br>
 }<br>
complex(){}<br>
voiddisplaydata(){<br>
cout<<"real part =" <<r<<endl;<br>
cout<<"imaginary part ="<<i<<endl;<br>
 }<br>
complexoperator+(complex c){<br>
returncomplex(r+c.r, i+c.i);<br>
 }<br>
};<br>
intmain(){<br>
complexa(2,3);<br>
complexb(3,4);<br>
complex c=a+b;<br>
c.displaydata();<br>
return0;<br>
}<br>
<hr width="50%" align="left">
<font color="red">3. What is polymorphism in C++?</font><br>
Polymorphism in simple means having many forms. Its behavior is different in different situations. And this occurs when we have multiple classes that are related to each other by inheritance.<br>
For example, think of a base class called a car that has a method called car brand(). Derived classes of cars could be Mercedes, BMW, Audi - And they also have their own implementation of a cars<br>
The two types of polymorphism in c++ are:
<ul>
	<li>Compile Time Polymorphism
	<li>Runtime Polymorphism
</ul>
<hr width="50%" align="left">
<font color="red">4. Explain constructor in C++</font><br>
The constructor is a member function that is executed automatically whenever an object is created. Constructors have the same name as the class of which they are members so that compiler knows that the member function is a constructor. And no return type is used for constructors.<br>
Example:<br>
classA{<br>
private:<br>
intval;<br>
public:<br>
A(int x){             //one argument constructor<br>
val=x;<br>
  }<br>
A(){                    //zero argument constructor<br>
  }<br>
}<br>
intmain(){<br>
A a(3);     <br>
return0;<br>
}
<hr width="50%" align="left">
<font color="red">5. What are the C++ access specifiers?</font><br>
In C++ there are the following access specifiers:<br>
Public: All data members and member functions are accessible outside the class.<br>
Protected: All data members and member functions are accessible inside the class and to the derived class.<br>
Private: All data members and member functions are not accessible outside the class.
<hr width="50%" align="left">
<font color="red">6. Define inline function</font><br>
If a function is inline, the compiler places a copy of the code of that function at each point where the function is called at compile time. One of the important advantages of using an inline function is that it eliminates the function calling overhead of a traditional function.
<hr width="50%" align="left">
<font color="red">7. What is a reference in C++?</font><br>
A reference is like a pointer. It is another name of an already existing variable. Once a reference name is initialized with a variable, that variable can be accessed by the variable name or reference name both.<br>
For example-<br>
int x=10;<br>
int&ref=x;   //reference variable<br>
If we change the value of ref it will be reflected in x. Once a reference variable is initialized it cannot refer to any other variable. We can declare an array of pointers but an array of references is not possible.
<hr width="50%" align="left">
<font color="red">8. What do you mean by call by value and call by reference?</font><br>
In call by value method, we pass a copy of the parameter is passed to the functions. For these copied values a new memory is assigned and changes made to these values do not reflect the variable in the main function.<br>
In call by reference method, we pass the address of the variable and the address is used to access the actual argument used in the function call. So changes made in the parameter alter the passing argument.
<hr width="50%" align="left">
<font color="red">9. What are the static members and static member functions?</font><br>
When a variable in a class is declared static, space for it is allocated for the lifetime of the program. No matter how many objects of that class have been created, there is only one copy of the static member. So same static member can be accessed by all the objects of that class.<br>
A static member function can be called even if no objects of the class exist and the static function are accessed using only the class name and the scope resolution operator ::
<hr width="50%" align="left">
<font color="red">10. What is an abstract class and when do you use it?</font><br>
A class is called an abstract class whose objects can never be created. Such a class exists as a parent for the derived classes. We can make a class abstract by placing a pure virtual function in the class.
</font>
</body>
</html>