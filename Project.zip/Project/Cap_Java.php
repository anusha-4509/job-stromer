<?php
?>
<html>
<head><title>Java</title></head>
<body>
<h1>Java</h1>
<font face="verdana" size="3">
<hr width="50%" align="left">
<font color="red"><b>Q1.Explain public static void main(String args[]) in Java. </b></font><br>
<b>Answer:</b><br>
main() in Java refers to the entry point for any Java program and is always written as public static void main(String[] args). <br>
<br>
<b>public:</b> Public is an access modifier. It is used to specify who can access this method. Public means that this Method could be accessed by any Class. <br>
<br>
<b>Static:</b> Static is a keyword that identifies it is class-based. main() is made static in Java so that it can be accessed without creating the instance of a class but if main is not made static then the compiler will throw an error as main() which is then called by the JVM before any objects are made and only static methods can be directly invoked via the class.<br>
<br>
<b>void:</b> Void refers to the return type of the method and it defines the method which will not return any value. <br>
<br>
<b>main:</b> It is the name of the method which is searched by JVM as a starting point for an application with a particular signature only and main is the method where the main execution occurs. <br>
<br>
<b>String args[]:</b> This is the parameter that is passed to the main method.
<hr width="50%" align="left">
<font color="red"><b>Q2. Is Java platform-independent, if yes why?</b></font><br>
<b>Answer:</b><br>
 Yes, Java is platform-independent. This is because for every operating system present a separate JVM is available which is capable to read the .class file or byte code.<br>
But while JAVA is a platform-independent language, the JVM is platform-dependent. Different JVM is designed for different OS and the byte code is capable of running on different OS. <br>
<hr width="50%" align="left">
<font color="red"><b>Q3. What are constructors in Java?</b></font><br>
<b>Answer:</b><br>
A constructor in Java refers to a block of code which is used to initialize an object and it must have the same name as that of the class. Also, a constructor does not have a return type and it is automatically called when an object is created. There are two types of constructors in Java. <br>
<br>
They are :<br>
<br>
 <b>Default Constructor:</b> A default constructor does not take any inputs. In simple terms, default constructors are the no-argument constructors which will be created by default in case no other constructor is defined by the user. The main purpose of a default constructor is to initialize the instance variables with the default values. Also, it is majorly used for object creation. <br>
<br>
<b>Parameterized Constructor:</b> A parameterized constructor, unlike the default constructor, is capable of initializing the instance variables with the provided values. In other words, the constructors which take the arguments are called parameterized constructors. 
<hr width="50%" align="left">
<font color="red"><b>Q4. What is the final keyword in Java?</b></font><br>
<b>Answer:</b><br>
final is a special keyword in Java and can be used as a non-access modifier. It could be used in different contexts. They are given below the <br>
<b>final variable:</b> When the final keyword is used with a variable then its value can't be changed and if you consider the case where no value has been assigned to the final variable then with the help of the class constructor a value can be assigned to it. <br>
<br>
<b>final method:</b> A simple way to explain the final method is, when a method is declared final then it can't be overridden by the inheriting class. <br>
<br>
<b>final class:</b> When you declare a class as final, it can't be extended by any subclass class but it can extend other class.
<hr width="50%" align="left">
<font color="red"><b>Q5. What is Java String Pool?</b></font><br>
<b>Answer</b><br>
It refers to a string collection that is stored in heap memory. <br>
So, whenever a new object is created, the String pool first checks whether the object is already present in the pool or not, and if it is present then the same reference is returned to the variable.<br>
Otherwise, a new object will be created in the String pool and the respective reference will be returned.
<hr width="50%" align="left">
<font color="red"><b>Q6. Why Java Strings are immutable in nature? </b></font><br>
<b>Answer:</b><br>
 In Java, string objects are immutable in nature. <br>
This means that once the String object is created its state cannot be modified. So, if you do try to update the value of that object instead of updating the values of that particular object, Java creates a new string object. <br>
Java String objects happen to be immutable as String objects are generally cached in the String pool.<br>
As the String literals are usually shared between multiple clients, action from one client might affect the rest. <br>
By doing so, it enhances the security, caching, synchronization, and performance of the application. <br>
</font>
</body>
</html>