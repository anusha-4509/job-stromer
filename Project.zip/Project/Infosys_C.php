<?php
require('connection.php');
$query = "select * from table "
?>
$c = $_SESSION['clicks'];
<html>
<head><title>C Lang</title></head>
<body>
<h1>C Language</h1>
<hr width="50%" align="left">
<font face="verdana" size="3">
<?php if(isset($c)) {
$fetchqry = "SELECT * FROM `infosys_clang`"
?>
</font>
</body>
</html>