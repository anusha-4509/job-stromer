<?php
?>
<html>
<head>
<title>Written Test</title>
 <body bgcolor = "lightyellow">
<font face="corbel" size="5">
<p align="center">These are the topics of Written Test </p><br>
<table border="0" align="center" cellpadding="5" cellspacing="5">
<tr>
	<td><a href = "Infosys_reasoning.php">Resoning Ability</a>
</tr>
<tr>
	<td><a href = "infosys_aptitude.php">Mathematical Ability</a>
</tr>
<tr>
	<td><a href="infosys_verbal.php">Verbal Ability</a>
</tr>
<tr>
	<td><a href="infosys_puzzles.php">Puzzles</a>
</tr>
</table>
</font>
</body>
</head>
</html>